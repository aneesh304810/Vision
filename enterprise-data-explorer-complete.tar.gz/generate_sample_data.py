"""
Sample Data Generator for Enterprise Data Explorer
Generates realistic test data for development and testing
"""

import pandas as pd
import random
from datetime import datetime

# ========================================================
# SAMPLE DATA CONFIGURATION
# ========================================================

SYSTEMS = [
    "SAP", "Oracle_ERP", "Salesforce", "DataWarehouse", "Microsoft_Dynamics",
    "Workday", "ServiceNow", "Tableau", "Power_BI", "Snowflake",
    "PostgreSQL", "MongoDB", "Redis", "Kafka", "Addvantage"
]

APPLICATIONS = [
    "Customer_Portal", "Finance_System", "HR_Management", "Sales_CRM",
    "Inventory_Management", "Reporting_Platform", "Analytics_Engine",
    "Data_Integration_Hub", "ETL_Pipeline", "Master_Data_Management"
]

INTEGRATION_TYPES = [
    "API", "Batch", "Feed", "Database", "STP", "Report", "Direct", "Sharepoint"
]

SQL_QUERY_NAMES = [
    "customer_daily_extract", "account_balance_query", "transaction_history",
    "user_activity_report", "inventory_status", "sales_summary",
    "tax_document_extract", "regulatory_report", "audit_trail",
    "product_catalog_sync", "order_fulfillment", "payment_processing"
]

TABLE_PREFIXES = [
    "CUST", "ACCT", "TXN", "PROD", "ORD", "INV", "USR", "RPT", "FIN", "TAX"
]

COLUMN_NAMES = [
    "ACCOUNT_NUMBER", "CUSTOMER_ID", "TRANSACTION_ID", "AMOUNT", "STATUS",
    "CREATE_DATE", "UPDATE_DATE", "USER_ID", "PRODUCT_ID", "QUANTITY",
    "TRADE_DATE", "SETTLEMENT_DATE", "TAX_STATUS", "BALANCE", "BRANCH_CODE"
]

# ========================================================
# INTERFACE INVENTORY GENERATOR
# ========================================================

def generate_interface_inventory(num_interfaces=50):
    """Generate sample interface inventory data"""
    
    data = []
    
    for i in range(num_interfaces):
        source = random.choice(SYSTEMS)
        target = random.choice([s for s in SYSTEMS if s != source])
        application = random.choice(APPLICATIONS)
        int_type = random.choice(INTEGRATION_TYPES)
        
        integration_name = f"{source}_{target}_{int_type}_{i+1:03d}"
        
        descriptions = [
            f"Daily {int_type.lower()} integration from {source} to {target}",
            f"Real-time data sync between {source} and {target}",
            f"Batch transfer of {random.choice(['customer', 'transaction', 'account'])} data",
            f"API integration for {random.choice(['reporting', 'analytics', 'synchronization'])}",
            f"Feed from {source} to {target} for {random.choice(['reconciliation', 'reporting', 'backup'])}"
        ]
        
        data.append({
            "Integration": integration_name,
            "Application": application,
            "Source System": source,
            "Target System": target,
            "Type": int_type,
            "Description": random.choice(descriptions),
            "Inbound/Outbound with respect to existing ACCT platform": random.choice(["Inbound", "Outbound", "Bidirectional"])
        })
    
    df = pd.DataFrame(data)
    return df

# ========================================================
# SQL METADATA GENERATOR
# ========================================================

def generate_sql_query(query_name):
    """Generate a sample SQL query"""
    
    tables = [f"{random.choice(TABLE_PREFIXES)}_TABLE_{random.randint(1,20):02d}" for _ in range(random.randint(1, 3))]
    columns = random.sample(COLUMN_NAMES, random.randint(3, 8))
    
    # Generate SELECT statement
    sql = "SELECT\n"
    sql += ",\n".join([f"    {col}" for col in columns])
    sql += f"\nFROM {tables[0]}"
    
    # Add joins if multiple tables
    if len(tables) > 1:
        for i in range(1, len(tables)):
            join_col = random.choice(["ACCOUNT_ID", "CUSTOMER_ID", "TRANSACTION_ID", "USER_ID"])
            sql += f"\n{random.choice(['INNER', 'LEFT', 'RIGHT'])} JOIN {tables[i]}"
            sql += f"\n    ON {tables[0].split('_')[0]}.{join_col} = {tables[i].split('_')[0]}.{join_col}"
    
    # Add WHERE clause
    where_conditions = []
    if random.random() > 0.3:
        where_conditions.append(f"{random.choice(columns)} IS NOT NULL")
    if random.random() > 0.5:
        status_vals = ["'A'", "'C'", "'P'"]
        where_conditions.append(f"STATUS IN ({', '.join(random.sample(status_vals, 2))})")
    if random.random() > 0.4:
        where_conditions.append(f"CREATE_DATE >= TRUNC(SYSDATE) - 30")
    
    if where_conditions:
        sql += "\nWHERE\n    " + "\n    AND ".join(where_conditions)
    
    # Add ORDER BY
    if random.random() > 0.5:
        sql += f"\nORDER BY {random.choice(columns)} DESC"
    
    sql += ";"
    
    return sql, tables, columns

def generate_plsql_procedure(proc_name):
    """Generate a sample PL/SQL procedure"""
    
    plsql = f"""CREATE OR REPLACE PROCEDURE {proc_name}
(
    p_account_id IN NUMBER,
    p_status OUT VARCHAR2
)
AS
    v_balance NUMBER;
    v_count NUMBER;
BEGIN
    -- Validate input
    IF p_account_id IS NULL THEN
        RAISE_APPLICATION_ERROR(-20001, 'Account ID cannot be null');
    END IF;
    
    -- Get account balance
    SELECT balance
    INTO v_balance
    FROM ACCT_MASTER
    WHERE account_id = p_account_id;
    
    -- Process transactions
    FOR rec IN (
        SELECT transaction_id, amount
        FROM TXN_HISTORY
        WHERE account_id = p_account_id
        AND status = 'P'
    ) LOOP
        UPDATE TXN_HISTORY
        SET status = 'C',
            process_date = SYSDATE
        WHERE transaction_id = rec.transaction_id;
        
        v_balance := v_balance + rec.amount;
    END LOOP;
    
    -- Update account
    UPDATE ACCT_MASTER
    SET balance = v_balance,
        last_update = SYSDATE
    WHERE account_id = p_account_id;
    
    COMMIT;
    
    p_status := 'SUCCESS';
    
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        ROLLBACK;
        p_status := 'ACCOUNT_NOT_FOUND';
    WHEN OTHERS THEN
        ROLLBACK;
        p_status := 'ERROR: ' || SQLERRM;
END {proc_name};
/"""
    
    return plsql

def generate_sql_metadata(num_queries=30):
    """Generate sample SQL metadata"""
    
    data = []
    
    for i in range(num_queries):
        query_type = random.choice(["SQL", "SQL", "SQL", "PLSQL"])  # 75% SQL, 25% PL/SQL
        query_name = f"{random.choice(SQL_QUERY_NAMES)}_{i+1:03d}"
        
        if query_type == "SQL":
            sql, tables, columns = generate_sql_query(query_name)
            
            data.append({
                "QueryName": query_name,
                "File": f"sql_files/{query_name}.sql",
                "RawSQL": sql,
                "Tables": ", ".join(tables),
                "SelectColumns": ", ".join(columns)
            })
        else:
            proc_name = f"PROC_{query_name.upper()}"
            plsql = generate_plsql_procedure(proc_name)
            
            data.append({
                "QueryName": proc_name,
                "File": f"plsql_files/{proc_name}.pls",
                "RawSQL": plsql,
                "Tables": "ACCT_MASTER, TXN_HISTORY",
                "SelectColumns": "Various"
            })
    
    df = pd.DataFrame(data)
    return df

# ========================================================
# MAIN GENERATOR FUNCTION
# ========================================================

def generate_sample_data(
    num_interfaces=50,
    num_queries=30,
    output_interface_file="sample_interface_inventory.xlsx",
    output_sql_file="sample_sql_metadata.xlsx"
):
    """
    Generate complete sample dataset for testing
    
    Args:
        num_interfaces: Number of interface records to generate
        num_queries: Number of SQL/PL-SQL queries to generate
        output_interface_file: Output filename for interface inventory
        output_sql_file: Output filename for SQL metadata
    """
    
    print(f"Generating {num_interfaces} interface records...")
    interface_df = generate_interface_inventory(num_interfaces)
    
    print(f"Generating {num_queries} SQL queries...")
    sql_df = generate_sql_metadata(num_queries)
    
    # Save to Excel files
    print(f"Saving interface inventory to {output_interface_file}...")
    with pd.ExcelWriter(output_interface_file, engine='openpyxl') as writer:
        interface_df.to_excel(writer, sheet_name='interface', index=False)
    
    print(f"Saving SQL metadata to {output_sql_file}...")
    with pd.ExcelWriter(output_sql_file, engine='openpyxl') as writer:
        sql_df.to_excel(writer, sheet_name='Queries', index=False)
    
    print("\n✅ Sample data generation complete!")
    print(f"   - Interface Inventory: {output_interface_file}")
    print(f"   - SQL Metadata: {output_sql_file}")
    print(f"\nSummary:")
    print(f"   - {len(interface_df)} interfaces")
    print(f"   - {len(interface_df['Source System'].unique())} unique source systems")
    print(f"   - {len(interface_df['Target System'].unique())} unique target systems")
    print(f"   - {len(sql_df)} SQL queries")
    print(f"   - {len(sql_df[sql_df['RawSQL'].str.contains('PROCEDURE', na=False)])} PL/SQL procedures")
    
    return interface_df, sql_df

# ========================================================
# CLI INTERFACE
# ========================================================

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Generate sample data for Enterprise Data Explorer")
    parser.add_argument("--interfaces", type=int, default=50, help="Number of interface records (default: 50)")
    parser.add_argument("--queries", type=int, default=30, help="Number of SQL queries (default: 30)")
    parser.add_argument("--output-interfaces", default="sample_interface_inventory.xlsx", 
                       help="Output file for interface inventory")
    parser.add_argument("--output-sql", default="sample_sql_metadata.xlsx",
                       help="Output file for SQL metadata")
    
    args = parser.parse_args()
    
    generate_sample_data(
        num_interfaces=args.interfaces,
        num_queries=args.queries,
        output_interface_file=args.output_interfaces,
        output_sql_file=args.output_sql
    )
