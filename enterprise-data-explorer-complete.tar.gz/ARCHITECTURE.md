# 🏗️ Architecture & Design Documentation

## System Architecture

### High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    User Interface (Streamlit)                    │
│  ┌───────────┬──────────┬──────────┬──────────┬──────────────┐  │
│  │   Home    │  System  │Integration│   SQL    │  Interface   │  │
│  │ & Upload  │ Lineage  │Deep-Dive │Knowledge │SQL Mapping   │  │
│  └───────────┴──────────┴──────────┴──────────┴──────────────┘  │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                     Application Layer                            │
│  ┌──────────────────┬──────────────────┬─────────────────────┐  │
│  │ Data Processors  │  AI/ML Engine    │  Graph Generator    │  │
│  │ - SQL Parser     │  - Embeddings    │  - Node Builder     │  │
│  │ - Enrichment     │  - LLM Prompts   │  - Edge Builder     │  │
│  │ - Mapping        │  - Similarity    │  - Layout Manager   │  │
│  └──────────────────┴──────────────────┴─────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                     AI/ML Models Layer                           │
│  ┌──────────────────────────────┬─────────────────────────────┐ │
│  │   Sentence Transformers       │   Phi-3 Mini LLM            │ │
│  │   - all-MiniLM-L6-v2         │   - Text Generation         │ │
│  │   - Semantic Similarity      │   - Business Explanations   │ │
│  │   - Column Matching          │   - Technical Docs          │ │
│  └──────────────────────────────┴─────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                      Data Layer                                  │
│  ┌──────────────┬──────────────┬────────────┬─────────────────┐│
│  │  Interface   │   SQL Meta   │  Enriched  │    Lineage      ││
│  │  Inventory   │    Data      │   SQL      │    Mapping      ││
│  │  (Excel)     │   (Excel)    │  (Excel)   │    (Excel)      ││
│  └──────────────┴──────────────┴────────────┴─────────────────┘│
└─────────────────────────────────────────────────────────────────┘
```

---

## Component Details

### 1. Data Input Components

#### Interface Inventory Loader
- **Purpose**: Parse and validate interface integration data
- **Input**: Excel file with "interface" sheet
- **Processing**: 
  - Column normalization
  - Data validation
  - Type checking
- **Output**: Pandas DataFrame

#### SQL Metadata Loader
- **Purpose**: Load SQL and PL/SQL code for analysis
- **Input**: Excel file with "Queries" sheet
- **Processing**:
  - Code validation
  - Initial parsing
  - Metadata extraction
- **Output**: Pandas DataFrame with raw SQL

### 2. Analysis & Processing Components

#### SQL Parser
- **Technology**: SQLGlot library
- **Capabilities**:
  - Parse SELECT, INSERT, UPDATE, DELETE
  - Extract tables, columns, joins
  - Identify WHERE clauses
  - Support for Oracle SQL dialect
- **Output**: Structured metadata dictionary

#### PL/SQL Analyzer
- **Technology**: Regex-based pattern matching
- **Extracts**:
  - Procedures and functions
  - Cursors and loops
  - DML operations
  - Exception handling
  - Transaction control
- **Output**: Procedural code metadata

#### Governance Rule Classifier
- **Purpose**: Identify data governance patterns
- **Rules Detected**:
  - Data quality checks (IS NOT NULL)
  - Domain filters (IN clauses)
  - Exclusion logic (NOT IN, NOT EXISTS)
  - Temporal filters (date functions)
  - Range filters (BETWEEN)
- **Output**: List of applicable rules

#### Business Glossary Mapper
- **Technology**: Semantic similarity via embeddings
- **Process**:
  1. Embed column names
  2. Compare with glossary embeddings
  3. Calculate cosine similarity
  4. Return best match with confidence
- **Threshold**: 0.6 minimum similarity
- **Output**: Column-to-term mappings with confidence scores

### 3. AI/ML Components

#### Embedding Model (MiniLM)
- **Model**: all-MiniLM-L6-v2
- **Size**: ~90MB
- **Dimensions**: 384
- **Use Cases**:
  - Semantic similarity matching
  - Column name to glossary mapping
  - Interface-SQL matching
- **Performance**: ~1000 embeddings/second on CPU

#### LLM Model (Phi-3 Mini)
- **Model**: Phi-3-mini-4k-instruct
- **Size**: ~3GB
- **Parameters**: 3.8B
- **Context**: 4K tokens
- **Use Cases**:
  - Generate business explanations
  - Generate technical documentation
  - Summarize complex SQL logic
- **Performance**: ~10-20 tokens/second on CPU

### 4. Matching Engine

#### Deterministic Matching
- **Integration name in query name**: +30 points
- **Application in file name**: +15 points
- **Source system in tables**: +15 points
- **Target system in file name**: +10 points
- **Valid integration type**: +10 points
- **Maximum score**: 100 points

#### Semantic Matching
- **High similarity (>0.75)**: +25 points
- **Medium similarity (0.65-0.75)**: +15 points
- **Low similarity (0.55-0.65)**: +10 points
- **Below threshold (<0.55)**: 0 points

#### Confidence Classification
- **High**: 85-100 points
- **Medium**: 65-84 points
- **Low**: 45-64 points
- **No Match**: <45 points

### 5. Visualization Components

#### System Lineage Graph
- **Technology**: Streamlit-AgGraph (based on vis.js)
- **Layout**: Hierarchical, left-to-right
- **Nodes**: Systems (source/target)
- **Edges**: Aggregated integrations
- **Features**:
  - Interactive pan/zoom
  - Click to filter
  - Color-coded by type
  - Dynamic tooltips

#### Integration Deep-Dive Graph
- **Layout**: Physics-based with curved edges
- **Multiple Edges**: Unique curves for each integration
- **Features**:
  - Curved CW/CCW routing
  - Dynamic spacing
  - Integration-level detail

---

## Data Flow

### 1. Upload & Validation Flow

```
User Upload → File Validation → Column Normalization 
    → Required Column Check → Data Type Validation 
    → Session State Storage → UI Confirmation
```

### 2. SQL Enrichment Flow

```
Raw SQL → Code Type Detection → Parse (SQL/PL-SQL)
    → Extract Metadata → Classify Governance Rules
    → Map to Glossary → Generate LLM Prompts
    → Call LLM (if enabled) → Combine Results
    → Save to Excel → Update Session State
```

### 3. Lineage Mapping Flow

```
Interface Data + SQL Data → For Each Interface:
    → Calculate Deterministic Score
    → Calculate Semantic Score (if enabled)
    → Combine Scores → Classify Confidence
    → Filter by Threshold → Aggregate Results
    → Save Mapping → Display in UI
```

### 4. Visualization Flow

```
Interface Data → Group by System Pairs
    → Create Nodes (Systems) → Create Edges (Integrations)
    → Apply Colors → Configure Layout
    → Render Graph → Handle Interactions
    → Update Display Data
```

---

## Performance Optimization

### Caching Strategy

1. **Model Caching** (`@st.cache_resource`)
   - Models loaded once per session
   - Shared across reruns
   - Cleared only on app restart

2. **Data Caching** (`@st.cache_data`)
   - Embeddings computed once
   - File parsing cached
   - Cleared on input change

3. **File Persistence**
   - Enriched data saved to Excel
   - Reloaded on subsequent runs
   - Avoids re-processing

### Vectorization

- Batch embedding generation
- Numpy operations for similarity
- Pandas vectorized operations
- Minimal Python loops

### Memory Management

- Stream large datasets
- Clear intermediate variables
- Use generators where possible
- Limit graph node count

---

## Security Considerations

### Data Privacy

- **No External Transmission**: All processing is local
- **No Logging of Sensitive Data**: SQL code not logged
- **Session Isolation**: Data cleared between sessions

### Input Validation

- **Excel Format Validation**: Check sheet names and columns
- **SQL Injection Prevention**: Code parsed, not executed
- **File Size Limits**: Streamlit default limits apply

### Access Control

- **None by default**: Consider adding authentication
- **Deployment Options**: Can integrate with corporate SSO
- **Audit Logging**: Optional - can be added

---

## Scalability

### Current Limits

- **Interface Records**: 10,000+
- **SQL Queries**: 5,000+ (with LLM disabled)
- **SQL Queries**: 1,000 (with LLM enabled)
- **Graph Nodes**: 100 systems
- **Graph Edges**: 1,000 integrations

### Scaling Strategies

1. **Batch Processing**: Process SQL in chunks
2. **Parallel Processing**: Use multiprocessing for embeddings
3. **Database Backend**: Replace Excel with SQL database
4. **Distributed LLM**: Use API-based LLM services
5. **Caching Layer**: Add Redis for shared cache

---

## Extensibility

### Adding New Features

1. **New View**: Add to sidebar radio and create view function
2. **New Analysis**: Add to enrichment pipeline
3. **New Visualization**: Use Streamlit or AgGraph
4. **New Model**: Add to model loading functions

### Plugin Architecture

Future enhancement: Plugin system for:
- Custom analyzers
- New data sources
- Additional visualizations
- Export formats

---

## Technology Stack

### Core Framework
- **Streamlit**: Web application framework
- **Python 3.9+**: Programming language

### Data Processing
- **Pandas**: Data manipulation
- **NumPy**: Numerical operations
- **OpenPyXL**: Excel file handling

### AI/ML
- **PyTorch**: Deep learning framework
- **Transformers**: HuggingFace models
- **Sentence-Transformers**: Embedding models
- **scikit-learn**: ML utilities

### SQL Processing
- **SQLGlot**: SQL parsing and analysis

### Visualization
- **Streamlit-AgGraph**: Network graphs
- **Streamlit-AgGrid**: Interactive tables
- **Native Streamlit**: Charts and metrics

---

## Deployment Architectures

### Option 1: Local Development
```
Developer Machine → Streamlit Dev Server → Browser
```

### Option 2: Shared Server
```
Users → Corporate Network → App Server → Streamlit → Local Files
```

### Option 3: Cloud Deployment
```
Users → Internet → Cloud Provider → Container → Streamlit → Cloud Storage
```

### Option 4: Docker Container
```
Docker Host → Container → Streamlit → Mounted Volume
```

---

## Monitoring & Observability

### Metrics to Track

1. **Performance**:
   - Page load times
   - Query processing duration
   - Model inference latency

2. **Usage**:
   - Active users
   - Files processed
   - Feature usage

3. **Quality**:
   - Matching accuracy
   - User feedback
   - Error rates

### Logging Strategy

- **Application Logs**: Streamlit logging
- **Error Tracking**: Exception handlers
- **Audit Trail**: User actions (optional)

---

## Testing Strategy

### Unit Tests
- Parser functions
- Matching logic
- Governance rules
- Glossary mapping

### Integration Tests
- End-to-end workflows
- File loading
- Model inference
- Graph generation

### Performance Tests
- Large dataset processing
- Memory usage
- Model loading time

### User Acceptance Tests
- Feature completeness
- UI/UX validation
- Documentation accuracy

---

## Future Enhancements

### Phase 2 Features
- [ ] Real-time data refresh
- [ ] User authentication
- [ ] Role-based access control
- [ ] Advanced search and filtering
- [ ] Query optimization recommendations

### Phase 3 Features
- [ ] Database backend
- [ ] API endpoints
- [ ] Collaborative annotations
- [ ] Version control integration
- [ ] Impact analysis

### Phase 4 Features
- [ ] Machine learning for auto-matching
- [ ] Natural language queries
- [ ] Automated documentation generation
- [ ] Data quality scoring
- [ ] Compliance reporting

---

## Maintenance

### Regular Tasks
- Update AI models quarterly
- Review and expand business glossary
- Tune matching thresholds based on feedback
- Update governance rule patterns
- Refresh documentation

### Dependencies
- Monitor security advisories
- Update packages monthly
- Test compatibility
- Review breaking changes

---

This architecture is designed to be:
- **Modular**: Easy to extend and modify
- **Scalable**: Can handle growing datasets
- **Maintainable**: Clear separation of concerns
- **Testable**: Functions designed for testing
- **Documented**: Comprehensive inline documentation
