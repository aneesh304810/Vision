# 🚀 Quick Start Guide

Get up and running with Enterprise Data Explorer in 5 minutes!

## ⚡ Super Quick Start (For Testing)

### Step 1: Generate Sample Data
```bash
python generate_sample_data.py
```

This creates:
- `sample_interface_inventory.xlsx` - 50 sample interfaces
- `sample_sql_metadata.xlsx` - 30 sample SQL queries

### Step 2: Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 3: Run the Application
```bash
streamlit run enterprise_data_explorer.py
```

### Step 4: Upload Sample Data
1. Go to "🏠 Home & Upload"
2. Upload `sample_interface_inventory.xlsx` as Interface Inventory
3. Upload `sample_sql_metadata.xlsx` as SQL Metadata
4. Click "🚀 Enrich SQL Data" (wait a few minutes)
5. Click "🔗 Generate Mapping"

### Step 5: Explore!
Navigate through the views and explore your data lineage!

---

## 📊 Using Your Own Data

### Interface Inventory Excel Format

**Sheet Name:** `interface`

**Required Columns:**
```
| Integration | Application | Source System | Target System | Type | Description |
```

**Example:**
```excel
Integration: SAP_Salesforce_API_001
Application: Customer_Portal
Source System: SAP
Target System: Salesforce
Type: API
Description: Real-time customer sync
```

### SQL Metadata Excel Format

**Sheet Name:** `Queries`

**Required Columns:**
```
| QueryName | File | RawSQL |
```

**Example:**
```excel
QueryName: customer_query_001
File: queries/customer.sql
RawSQL: SELECT * FROM customers WHERE status='A'
```

---

## 🎯 Common Use Cases

### 1. Find What SQL Queries Support an Interface
1. Go to "🔗 Interface-SQL Mapping"
2. Filter by interface name
3. View matched SQL queries and confidence scores
4. Click row to see SQL code

### 2. Visualize System Integration Flow
1. Go to "🌐 System Lineage"
2. Select source/target systems from filters
3. Click edges to see detailed integrations
4. Export the visualization

### 3. Understand What a SQL Query Does
1. Go to "📊 SQL Knowledge Engine"
2. Search for your query
3. Read Business and Technical explanations
4. Check Column Glossary for field meanings

### 4. Audit Governance Rules
1. Go to "⚖️ Governance Analytics"
2. View governance rules distribution
3. Check glossary coverage
4. Export reports

---

## 🔧 Configuration Tips

### Disable LLM for Faster Testing
Edit `config.py`:
```python
USE_LLM = False
```

### Use Online Models (No Download Required)
Edit `config.py`:
```python
EMBEDDING_MODEL_PATH = "all-MiniLM-L6-v2"
LLM_MODEL_PATH = "microsoft/Phi-3-mini-4k-instruct"
```

### Adjust Performance
Edit `config.py`:
```python
CPU_THREADS = 8  # Match your CPU cores
```

---

## 🐛 Troubleshooting

### "ModuleNotFoundError"
```bash
pip install -r requirements.txt
```

### "Sheet 'interface' not found"
- Check your Excel file has a sheet named exactly `interface`
- Check spelling and case

### "Memory Error"
- Close other applications
- Reduce `CPU_THREADS` in config.py
- Process smaller datasets

### Slow Performance
- Disable semantic matching temporarily
- Set `USE_LLM = False` in config.py
- Use sample data first to test

---

## 📚 Next Steps

1. ✅ Read the full [README.md](README.md) for complete documentation
2. ✅ Customize [config.py](config.py) for your environment
3. ✅ Add your business glossary terms to config.py
4. ✅ Try with your real data
5. ✅ Share feedback and suggestions!

---

## 💡 Pro Tips

- **Cache Results**: Enriched data is saved to Excel files for faster reloading
- **Filter Smart**: Use filters to focus on specific systems or integration types
- **Export Often**: Download CSVs of your views for further analysis
- **Customize Glossary**: Add your company-specific terms to config.py
- **Batch Processing**: For 1000+ queries, consider processing in batches

---

## 🎓 Learning Path

**Beginner:**
1. Start with sample data
2. Explore System Lineage view
3. Try the Integration Deep-Dive

**Intermediate:**
4. Upload your own data
5. Run SQL enrichment
6. Explore SQL Knowledge Engine

**Advanced:**
7. Customize business glossary
8. Tune matching scores
9. Add custom governance rules
10. Export and analyze results

---

## 📞 Getting Help

**Check these first:**
1. Error message in the app
2. Streamlit console logs
3. Troubleshooting section in README.md
4. Input data format requirements

**Still stuck?**
- Review sample data format
- Try with sample data first
- Check model paths in config.py

---

**Ready to explore your data lineage? Let's go! 🚀**
