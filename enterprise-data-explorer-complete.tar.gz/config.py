"""
Configuration file for Enterprise Data Explorer
Edit these values to customize the application
"""

# ========================================================
# MODEL PATHS
# ========================================================

# Embedding model for semantic similarity
# Options:
#   - Local path: "C:/SEI/AneeshModel/all-minilm-l6-v2"
#   - Online: "all-MiniLM-L6-v2" (will download automatically)
EMBEDDING_MODEL_PATH = "all-MiniLM-L6-v2"

# LLM model for generating explanations
# Options:
#   - Local: "C:/SEI/AneeshModel/phi-3-pytorch-phi-3.5-mini-instruct-v2"
#   - HuggingFace: "microsoft/Phi-3-mini-4k-instruct"
#   - None: Disable LLM features
LLM_MODEL_PATH = "microsoft/Phi-3-mini-4k-instruct"

# Enable/disable LLM features
USE_LLM = True  # Set to False to skip LLM loading (faster startup)

# ========================================================
# PERFORMANCE SETTINGS
# ========================================================

# CPU thread count for PyTorch
# Set to match your CPU core count for best performance
CPU_THREADS = 12

# Maximum tokens for LLM generation
MAX_TOKENS = 1000

# LLM Temperature (0.0 = deterministic, 1.0 = creative)
LLM_TEMPERATURE = 0.0

# ========================================================
# FILE PATHS
# ========================================================

# Output file names
ENRICHED_SQL_FILE = "enriched_sql_metadata.xlsx"
LINEAGE_MAPPING_FILE = "interface_sql_lineage.xlsx"

# ========================================================
# MATCHING CONFIGURATION
# ========================================================

# Default semantic matching settings
DEFAULT_ENABLE_SEMANTIC = True
DEFAULT_MIN_CONFIDENCE_SCORE = 65

# Semantic similarity thresholds
SEMANTIC_THRESHOLD_HIGH = 0.75   # Returns 25 points
SEMANTIC_THRESHOLD_MED = 0.65    # Returns 15 points
SEMANTIC_THRESHOLD_LOW = 0.55    # Returns 10 points

# Deterministic scoring weights
SCORE_INTEGRATION_MATCH = 30
SCORE_APPLICATION_MATCH = 15
SCORE_SOURCE_IN_TABLES = 15
SCORE_TARGET_IN_FILE = 10
SCORE_VALID_TYPE = 10

# ========================================================
# BUSINESS GLOSSARY
# ========================================================

BUSINESS_GLOSSARY = {
    # Account & Customer
    "ACCOUNT_NUMBER": "Unique account identifier for customer accounts",
    "ACCOUNT_ID": "Primary key for account records",
    "CUSTOMER_ID": "Unique customer identifier",
    "CUSTOMER_NAME": "Full name of the customer",
    "CLIENT_ID": "Client identification number",
    
    # Branch & Organization
    "BI101_ADMINISTRATIVE_BRANCH_NUM": "Administrative branch number for organizational hierarchy",
    "BRANCH_CODE": "Branch identifier code",
    "REGION_ID": "Geographic region identifier",
    "DIVISION": "Business division code",
    
    # Tax Related
    "BI74_TAX_OFFICER": "Assigned tax officer responsible for account",
    "TX1_TAX_STATUS": "Current tax reporting status of account",
    "UD62_TAX_STMT_DELIVERY_PREFEREN": "Customer preference for tax statement delivery method",
    "UD63_K1_DELIVERY_PREFERENCE": "K1 form delivery preference setting",
    "TAX_ID": "Tax identification number",
    "SSN": "Social Security Number",
    "EIN": "Employer Identification Number",
    
    # Transaction & Trading
    "TRADE_DATE": "Date when trade was executed",
    "SETTLEMENT_DATE": "Date when trade settles",
    "TRANSACTION_ID": "Unique transaction identifier",
    "TRADE_ID": "Trade identification number",
    "ORDER_ID": "Order identification number",
    
    # Financial
    "AMOUNT": "Monetary amount or transaction value",
    "BALANCE": "Current balance amount",
    "PRINCIPAL": "Principal amount",
    "INTEREST": "Interest amount",
    "FEE": "Fee or charge amount",
    "PRICE": "Price per unit",
    "QUANTITY": "Number of units",
    
    # Status & Classification
    "STATUS": "Current status or state of record",
    "ACCOUNT_STATUS": "Current account status",
    "TRANSACTION_STATUS": "Transaction processing status",
    "APPROVAL_STATUS": "Approval workflow status",
    "TYPE": "Type or category classification",
    "CATEGORY": "Category classification",
    
    # Dates & Timestamps
    "CREATE_DATE": "Record creation timestamp",
    "UPDATE_DATE": "Last modification timestamp",
    "EFFECTIVE_DATE": "Date when record becomes effective",
    "EXPIRY_DATE": "Date when record expires",
    "PROCESS_DATE": "Date when record was processed",
    
    # User & Security
    "USER_ID": "User identifier for access control",
    "USERNAME": "User login name",
    "CREATED_BY": "User who created the record",
    "MODIFIED_BY": "User who last modified the record",
    
    # Reference Data
    "PRODUCT_ID": "Product identifier",
    "PRODUCT_CODE": "Product code",
    "INSTRUMENT_ID": "Financial instrument identifier",
    "SECURITY_ID": "Security identifier",
    "CUSIP": "CUSIP number for securities",
    "ISIN": "International Securities Identification Number",
    
    # Address & Contact
    "ADDRESS": "Physical address",
    "CITY": "City name",
    "STATE": "State or province",
    "ZIP_CODE": "Postal code",
    "COUNTRY": "Country code or name",
    "PHONE": "Phone number",
    "EMAIL": "Email address",
    
    # Add your custom mappings here
}

# Minimum confidence score for glossary mapping
GLOSSARY_CONFIDENCE_THRESHOLD = 0.6

# ========================================================
# GOVERNANCE RULES
# ========================================================

# Define governance rule patterns
# Format: (pattern_to_match, rule_description)
GOVERNANCE_PATTERNS = [
    ("IS NOT NULL", "Data Quality – Mandatory field validation"),
    (" IN (", "Eligibility – Domain-based filtering"),
    ("NOT IN", "Compliance – Exclusion logic applied"),
    ("NOT EXISTS", "Compliance – Exclusion logic applied"),
    (" OR ", "Flexible – Multiple condition paths"),
    ("BETWEEN", "Range Filter – Bounded data selection"),
    ("SYSDATE", "Temporal – Date-based filtering"),
    ("CURRENT_DATE", "Temporal – Date-based filtering"),
    ("TRUNC", "Temporal – Date-based filtering"),
    ("DECODE", "Business Logic – Conditional transformation"),
    ("CASE", "Business Logic – Conditional transformation"),
    ("NVL", "Data Quality – Null handling"),
    ("COALESCE", "Data Quality – Null handling"),
    ("DISTINCT", "Data Quality – Deduplication"),
    ("GROUP BY", "Aggregation – Grouped calculation"),
    ("HAVING", "Aggregation – Post-group filtering"),
]

# ========================================================
# VISUALIZATION SETTINGS
# ========================================================

# Graph colors by integration type
INTEGRATION_TYPE_COLORS = {
    "api": "#42A5F5",           # Blue
    "direct": "#66BB6A",        # Green
    "batch": "#FB8C00",         # Orange
    "feed": "#AB47BC",          # Purple
    "report": "#FF7043",        # Red-Orange
    "data": "#8E24AA",          # Deep Purple
    "stp": "#26A69A",           # Teal
    "sharepoint": "#00ACC1",    # Cyan
    "database": "#FFA000",      # Amber
}

# Default edge color for unknown types
DEFAULT_EDGE_COLOR = "#666666"

# Node colors
SOURCE_NODE_COLOR = "#667eea"
TARGET_NODE_COLOR = "#764ba2"

# Graph dimensions
SYSTEM_GRAPH_HEIGHT = 700
INTEGRATION_GRAPH_HEIGHT = 600

# ========================================================
# UI CUSTOMIZATION
# ========================================================

# Application title and branding
APP_TITLE = "Enterprise Data Explorer"
APP_ICON = "🔍"
APP_SUBTITLE = "End-to-end data lineage, SQL knowledge, and governance platform"

# Confidence level thresholds
CONFIDENCE_HIGH_THRESHOLD = 85
CONFIDENCE_MEDIUM_THRESHOLD = 65
CONFIDENCE_LOW_THRESHOLD = 45

# Table display settings
DEFAULT_TABLE_HEIGHT = 400
DETAIL_TABLE_HEIGHT = 320

# ========================================================
# EXCLUDED INTEGRATION TYPES
# ========================================================

# These integration types will be filtered out from SQL mapping
# as they typically don't involve SQL queries
EXCLUDED_INTEGRATION_TYPES = [
    "api",
    "application",
    "multiple",
    "pdf",
    "sharepoint job",
]

# ========================================================
# PROMPTS FOR LLM
# ========================================================

# SQL Business Explanation Prompt Template
SQL_BUSINESS_PROMPT_TEMPLATE = """<|user|>
You are a data engineering expert explaining SQL to business executives.

Tables: {tables}
Columns: {columns}
Joins: {joins}
Filters: {filters}

Provide a clear, concise business explanation (2-3 paragraphs) of what this query does and why it matters to the business.
Focus on:
1. What business entities are involved
2. What business question this answers
3. Why this data is important

<|end|>
<|assistant|>
"""

# SQL Technical Explanation Prompt Template
SQL_TECHNICAL_PROMPT_TEMPLATE = """<|user|>
You are a senior data engineer explaining SQL technical implementation.

Tables: {tables}
Columns: {columns}
Joins: {joins}
Filters: {filters}

Provide detailed technical explanation including:
1. Join strategy and table relationships
2. Filter conditions and their impact on result set
3. Expected output structure and data types
4. Performance considerations (if any)

<|end|>
<|assistant|>
"""

# PL/SQL Business Explanation Prompt Template
PLSQL_BUSINESS_PROMPT_TEMPLATE = """<|user|>
You are a PL/SQL expert explaining database procedures to business stakeholders.

Object Type: {object_type}
DML Operations: {dml_operations}
Has Conditions: {has_conditions}
Has Loops: {has_loops}

Explain the business purpose and value of this PL/SQL object in 2-3 paragraphs.
Focus on:
1. What business process it supports
2. What data transformations it performs
3. Why it's important to the organization

<|end|>
<|assistant|>
"""

# PL/SQL Technical Explanation Prompt Template
PLSQL_TECHNICAL_PROMPT_TEMPLATE = """<|user|>
You are a senior Oracle engineer explaining PL/SQL implementation.

Object Type: {object_type}
Procedures: {procedures}
Functions: {functions}
Cursors: {cursors}
DML Operations: {dml_operations}
Exception Handling: {exception_handling}
Transaction Control: {transaction_control}

Provide detailed technical breakdown including:
1. Logic flow and control structures
2. Data processing steps
3. Error handling approach
4. Transaction management

<|end|>
<|assistant|>
"""

# ========================================================
# LOGGING
# ========================================================

# Enable debug logging
DEBUG_MODE = False

# Log file path (if None, logs to console only)
LOG_FILE_PATH = None

# ========================================================
# FEATURE FLAGS
# ========================================================

# Enable/disable features
ENABLE_SYSTEM_LINEAGE = True
ENABLE_INTEGRATION_DRILLDOWN = True
ENABLE_SQL_KNOWLEDGE = True
ENABLE_INTERFACE_MAPPING = True
ENABLE_GOVERNANCE_ANALYTICS = True

# Enable experimental features
ENABLE_QUERY_OPTIMIZATION_HINTS = False
ENABLE_DATA_QUALITY_CHECKS = False
ENABLE_AUTO_DOCUMENTATION = False
