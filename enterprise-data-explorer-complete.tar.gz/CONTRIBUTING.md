# Contributing to Enterprise Data Explorer

Thank you for your interest in contributing! 🎉

## Getting Started

1. Fork the repository
2. Clone your fork: `git clone https://github.com/your-username/enterprise-data-explorer.git`
3. Create a branch: `git checkout -b feature/your-feature-name`
4. Make your changes
5. Test thoroughly
6. Commit: `git commit -m "Add: your feature description"`
7. Push: `git push origin feature/your-feature-name`
8. Create a Pull Request

## Development Setup

```bash
# Create virtual environment
python -m venv venv
source venv/bin/activate  # or venv\Scripts\activate on Windows

# Install dependencies
pip install -r requirements.txt

# Generate test data
python generate_sample_data.py

# Run the app
streamlit run enterprise_data_explorer.py
```

## Code Style

- Follow PEP 8 guidelines
- Use meaningful variable names
- Add docstrings to functions
- Comment complex logic
- Keep functions focused and small

## Testing

Before submitting:
- [ ] Test with sample data
- [ ] Test with your own data
- [ ] Check all views work
- [ ] Verify error handling
- [ ] Test on different screen sizes

## Areas for Contribution

### High Priority
- [ ] Add unit tests
- [ ] Improve error messages
- [ ] Performance optimization
- [ ] Add more SQL dialects support

### Features
- [ ] Export to PDF reports
- [ ] Advanced filtering options
- [ ] Batch processing improvements
- [ ] User authentication
- [ ] API endpoints

### Documentation
- [ ] Video tutorials
- [ ] More examples
- [ ] Troubleshooting guides
- [ ] API documentation

### Bug Fixes
- Check [Issues](../../issues) for reported bugs

## Reporting Bugs

When reporting bugs, please include:
- Python version
- OS and version
- Steps to reproduce
- Expected vs actual behavior
- Error messages
- Screenshots if applicable

## Feature Requests

Feature requests are welcome! Please:
- Check existing issues first
- Describe the use case
- Explain the expected behavior
- Consider submitting a PR

## Pull Request Guidelines

- Keep PRs focused on a single feature/fix
- Update documentation
- Add tests if applicable
- Follow existing code style
- Reference related issues

## Questions?

- Open an issue for questions
- Tag with `question` label
- Be respectful and patient

Thank you for contributing! 🚀
