"""
========================================================
Enterprise Data Explorer - Unified Platform
========================================================
End-to-end data lineage, SQL knowledge, and exploration platform

Features:
1. Upload & Data Management
2. System Lineage Visualization
3. Integration Deep-Dive
4. SQL/PL-SQL Knowledge Engine
5. Interface-to-SQL Mapping
6. Data Governance & Analytics
========================================================
"""

import streamlit as st
import pandas as pd
import json
import re
import os
from collections import defaultdict
from io import BytesIO
import numpy as np

# ML/NLP Libraries
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM, pipeline
from sentence_transformers import SentenceTransformer, util
from sklearn.metrics.pairwise import cosine_similarity

# SQL Parsing
import sqlglot
from sqlglot.expressions import Table, Column, Join

# Visualization
from streamlit_agraph import agraph, Node, Edge, Config
from st_aggrid import AgGrid, GridOptionsBuilder, GridUpdateMode

# ========================================================
# CONFIGURATION
# ========================================================

st.set_page_config(
    page_title="Enterprise Data Explorer",
    page_icon="🔍",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Configure PyTorch for CPU
torch.set_num_threads(12)

# File paths
ENRICHED_SQL_FILE = "enriched_sql_metadata.xlsx"
LINEAGE_MAPPING_FILE = "interface_sql_lineage.xlsx"

# ========================================================
# STYLING
# ========================================================

st.markdown("""
<style>
    .main-header {
        font-size: 3rem;
        font-weight: bold;
        background: linear-gradient(90deg, #667eea 0%, #764ba2 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        margin-bottom: 0.5rem;
    }
    .sub-header {
        color: #666;
        font-size: 1.2rem;
        margin-bottom: 2rem;
    }
    .metric-card {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        padding: 1.5rem;
        border-radius: 10px;
        color: white;
        text-align: center;
    }
    .metric-value {
        font-size: 2.5rem;
        font-weight: bold;
    }
    .metric-label {
        font-size: 0.9rem;
        opacity: 0.9;
    }
    .section-divider {
        border-top: 2px solid #667eea;
        margin: 2rem 0;
    }
</style>
""", unsafe_allow_html=True)

# ========================================================
# MODEL LOADING
# ========================================================

@st.cache_resource
def load_embedding_model():
    """Load MiniLM for semantic similarity"""
    try:
        return SentenceTransformer("C:/SEI/AneeshModel/all-minilm-l6-v2")
    except Exception as e:
        st.warning(f"Could not load local model: {e}. Using online model.")
        return SentenceTransformer("all-MiniLM-L6-v2")

@st.cache_resource
def load_llm_model():
    """Load Phi-3 Mini for text generation"""
    try:
        model_path = "C:/SEI/AneeshModel/phi-3-pytorch-phi-3.5-mini-instruct-v2"
        tokenizer = AutoTokenizer.from_pretrained(model_path)
        model = AutoModelForCausalLM.from_pretrained(
            model_path,
            device_map="cpu",
            torch_dtype=torch.float16
        )
        return pipeline(
            "text-generation",
            model=model,
            tokenizer=tokenizer,
            do_sample=False,
            temperature=0.0,
            max_new_tokens=1000
        )
    except Exception as e:
        st.warning(f"LLM model not available: {e}")
        return None

# Initialize models
with st.spinner("Loading AI models..."):
    embedding_model = load_embedding_model()
    llm_model = load_llm_model()

# ========================================================
# SESSION STATE INITIALIZATION
# ========================================================

if 'interface_df' not in st.session_state:
    st.session_state.interface_df = None
if 'sql_df' not in st.session_state:
    st.session_state.sql_df = None
if 'enriched_sql_df' not in st.session_state:
    st.session_state.enriched_sql_df = None
if 'lineage_mapping_df' not in st.session_state:
    st.session_state.lineage_mapping_df = None
if 'current_view' not in st.session_state:
    st.session_state.current_view = "Home"

# ========================================================
# UTILITY FUNCTIONS
# ========================================================

def normalize_text(text):
    """Normalize text for matching"""
    if not isinstance(text, str):
        return ""
    return text.lower().replace("_", "").replace(" ", "").strip()

def safe_get(row, column, default=""):
    """Safely get value from row"""
    try:
        val = row.get(column, default) if isinstance(row, dict) else getattr(row, column, default)
        return val if pd.notna(val) else default
    except:
        return default

def edge_color_by_type(types):
    """Determine edge color based on integration type"""
    types = {str(t).lower() for t in types}
    color_map = {
        "api": "#42A5F5",
        "direct": "#66BB6A",
        "batch": "#FB8C00",
        "feed": "#AB47BC",
        "report": "#FF7043",
        "data": "#8E24AA",
        "stp": "#26A69A",
        "sharepoint": "#00ACC1",
        "database": "#FFA000"
    }
    for t in types:
        for key, color in color_map.items():
            if key in t:
                return color
    return "#666666"

# ========================================================
# DATA LOADING FUNCTIONS
# ========================================================

def load_interface_inventory(file):
    """Load and normalize interface inventory Excel"""
    try:
        df = pd.read_excel(file, sheet_name="interface")
    except Exception as e:
        st.error(f"❌ Could not read 'interface' sheet: {e}")
        return None
    
    # Normalize column names
    df.columns = (
        df.columns.astype(str)
        .str.replace('"', '', regex=False)
        .str.strip()
        .str.lower()
        .str.replace(" ", "_")
        .str.replace("/", "_")
        .str.replace("-", "_")
        .str.replace("__+", "_", regex=True)
    )
    
    # Remove unnamed columns
    df = df.loc[:, ~df.columns.str.contains("^unnamed")]
    
    # Handle inbound/outbound column
    if "inbound_outbound_with_respect_to_existing_acct_platform" in df.columns:
        df["inbound_outbound"] = df["inbound_outbound_with_respect_to_existing_acct_platform"]
    elif "inbound_outbound" not in df.columns:
        df["inbound_outbound"] = ""
    
    # Validate required columns
    required = ["source_system", "target_system", "integration", "type"]
    missing = [c for c in required if c not in df.columns]
    if missing:
        st.error(f"❌ Missing required columns: {', '.join(missing)}")
        return None
    
    # Clean string columns
    for col in required + ["inbound_outbound", "application", "description"]:
        if col in df.columns:
            df[col] = df[col].astype(str).str.strip()
    
    return df

def load_sql_metadata(file):
    """Load SQL metadata Excel"""
    try:
        df = pd.read_excel(file, sheet_name="Queries")
    except Exception as e:
        st.error(f"❌ Could not read 'Queries' sheet: {e}")
        return None
    
    # Normalize column names
    df.columns = [col.strip().lower().replace(" ", "_") for col in df.columns]
    
    # Validate required columns
    required = ["queryname", "rawsql"]
    missing = [c for c in required if c not in df.columns]
    if missing:
        st.error(f"❌ Missing required columns: {', '.join(missing)}")
        return None
    
    return df

# ========================================================
# SQL/PL-SQL ANALYSIS FUNCTIONS
# ========================================================

def detect_code_type(raw_code):
    """Detect if code is SQL or PL/SQL"""
    if not isinstance(raw_code, str):
        return "UNKNOWN"
    s = raw_code.strip().upper()
    if s.startswith("SELECT"):
        return "SQL"
    if any(keyword in s for keyword in ["PROCEDURE", "FUNCTION", "BEGIN", "DECLARE"]):
        return "PLSQL"
    return "UNKNOWN"

def extract_sql_metadata(raw_sql):
    """Parse SQL and extract metadata"""
    try:
        tree = sqlglot.parse_one(raw_sql, read="oracle")
    except Exception:
        return {
            "CodeType": "SQL",
            "Tables": "",
            "SelectColumns": "",
            "SelectColumnsCount": 0,
            "JoinConditions": "",
            "FilterConditions": ""
        }
    
    tables = sorted({t.sql() for t in tree.find_all(Table)})
    columns = sorted({c.sql() for c in tree.find_all(Column)})
    joins = [j.sql() for j in tree.find_all(Join)]
    where = tree.args.get("where")
    
    return {
        "CodeType": "SQL",
        "Tables": ", ".join(tables),
        "SelectColumns": ", ".join(columns),
        "SelectColumnsCount": len(columns),
        "JoinConditions": "\n".join(joins),
        "FilterConditions": where.sql() if where else ""
    }

def parse_plsql(raw_code):
    """Parse PL/SQL and extract metadata"""
    if not isinstance(raw_code, str):
        return {}
    
    return {
        "CodeType": "PLSQL",
        "ObjectType": (
            "PROCEDURE" if "PROCEDURE" in raw_code.upper() else
            "FUNCTION" if "FUNCTION" in raw_code.upper() else
            "PACKAGE"
        ),
        "Procedures": len(re.findall(r'PROCEDURE\s+(\w+)', raw_code, re.I)),
        "Functions": len(re.findall(r'FUNCTION\s+(\w+)', raw_code, re.I)),
        "Cursors": len(re.findall(r'CURSOR\s+(\w+)', raw_code, re.I)),
        "DML_Operations": ", ".join(set(re.findall(r'\b(INSERT|UPDATE|DELETE|MERGE)\b', raw_code, re.I))),
        "Has_Conditions": "Yes" if re.search(r'\b(IF|CASE)\b', raw_code, re.I) else "No",
        "Has_Loops": "Yes" if re.search(r'\b(FOR|WHILE|LOOP)\b', raw_code, re.I) else "No",
        "Exception_Handling": "Yes" if re.search(r'\bEXCEPTION\b', raw_code, re.I) else "No",
        "Has_Transaction_Control": "Yes" if re.search(r'\b(COMMIT|ROLLBACK)\b', raw_code, re.I) else "No"
    }

def classify_governance_rules(filter_sql):
    """Extract governance rules from SQL filters"""
    if not filter_sql:
        return []
    
    f = str(filter_sql).upper()
    rules = []
    
    if "IS NOT NULL" in f:
        rules.append("Data Quality – Mandatory field validation")
    if " IN (" in f:
        rules.append("Eligibility – Domain-based filtering")
    if "NOT IN" in f or "NOT EXISTS" in f:
        rules.append("Compliance – Exclusion logic applied")
    if "OR" in f:
        rules.append("Flexible – Multiple condition paths")
    if "BETWEEN" in f:
        rules.append("Range Filter – Bounded data selection")
    if any(date_func in f for date_func in ["SYSDATE", "CURRENT_DATE", "TRUNC"]):
        rules.append("Temporal – Date-based filtering")
    
    return rules

# ========================================================
# BUSINESS GLOSSARY
# ========================================================

BUSINESS_GLOSSARY = {
    "ACCOUNT_NUMBER": "Unique account identifier for customer accounts",
    "ACCOUNT_ID": "Primary key for account records",
    "BI101_ADMINISTRATIVE_BRANCH_NUM": "Administrative branch number for organizational hierarchy",
    "BI74_TAX_OFFICER": "Assigned tax officer responsible for account",
    "TX1_TAX_STATUS": "Current tax reporting status of account",
    "UD62_TAX_STMT_DELIVERY_PREFEREN": "Customer preference for tax statement delivery method",
    "UD63_K1_DELIVERY_PREFERENCE": "K1 form delivery preference setting",
    "CUSTOMER_ID": "Unique customer identifier",
    "TRADE_DATE": "Date when trade was executed",
    "SETTLEMENT_DATE": "Date when trade settles",
    "AMOUNT": "Monetary amount or transaction value",
    "STATUS": "Current status or state of record",
    "CREATE_DATE": "Record creation timestamp",
    "UPDATE_DATE": "Last modification timestamp",
    "USER_ID": "User identifier for access control"
}

@st.cache_data
def build_glossary_embeddings():
    """Build embeddings for business glossary"""
    return {
        k: embedding_model.encode(v, convert_to_tensor=True)
        for k, v in BUSINESS_GLOSSARY.items()
    }

glossary_embeddings = build_glossary_embeddings()

def map_column_to_glossary(column_name):
    """Map column to business glossary using semantic similarity"""
    if not column_name:
        return None, 0.0
    
    # Extract just the column name if it's schema.table.column
    clean_col = column_name.split(".")[-1].upper()
    
    # Direct match
    if clean_col in BUSINESS_GLOSSARY:
        return clean_col, 1.0
    
    # Semantic matching
    emb = embedding_model.encode(clean_col.replace("_", " "), convert_to_tensor=True)
    best_match, best_score = None, 0
    
    for k, v in glossary_embeddings.items():
        score = util.cos_sim(emb, v).item()
        if score > best_score:
            best_match, best_score = k, score
    
    return best_match if best_score > 0.6 else None, round(best_score, 2)

# ========================================================
# LLM EXPLANATION GENERATION
# ========================================================

def generate_llm_explanation(prompt):
    """Generate explanation using LLM"""
    if llm_model is None:
        return "LLM model not available. Please check model configuration."
    
    try:
        result = llm_model(prompt, return_full_text=False)
        return result[0]["generated_text"]
    except Exception as e:
        return f"Error generating explanation: {str(e)}"

def create_sql_business_prompt(meta):
    """Create prompt for SQL business explanation"""
    return f"""<|user|>
You are a data engineering expert explaining SQL to business executives.

Tables: {meta.get('Tables', 'N/A')}
Columns: {meta.get('SelectColumns', 'N/A')}
Joins: {meta.get('JoinConditions', 'N/A')}
Filters: {meta.get('FilterConditions', 'N/A')}

Provide a clear, concise business explanation (2-3 paragraphs) of what this query does and why it matters to the business.
<|end|>
<|assistant|>
"""

def create_sql_technical_prompt(meta):
    """Create prompt for SQL technical explanation"""
    return f"""<|user|>
You are a senior data engineer explaining SQL technical implementation.

Tables: {meta.get('Tables', 'N/A')}
Columns: {meta.get('SelectColumns', 'N/A')}
Joins: {meta.get('JoinConditions', 'N/A')}
Filters: {meta.get('FilterConditions', 'N/A')}

Provide detailed technical explanation including:
- Join strategy and relationships
- Filter impact on result set
- Expected output structure
- Performance considerations
<|end|>
<|assistant|>
"""

def create_plsql_business_prompt(meta):
    """Create prompt for PL/SQL business explanation"""
    return f"""<|user|>
You are a PL/SQL expert explaining database procedures to business stakeholders.

Object Type: {meta.get('ObjectType', 'N/A')}
DML Operations: {meta.get('DML_Operations', 'N/A')}
Has Conditions: {meta.get('Has_Conditions', 'N/A')}
Has Loops: {meta.get('Has_Loops', 'N/A')}

Explain the business purpose and value of this PL/SQL object in 2-3 paragraphs.
<|end|>
<|assistant|>
"""

def create_plsql_technical_prompt(meta):
    """Create prompt for PL/SQL technical explanation"""
    return f"""<|user|>
You are a senior Oracle engineer explaining PL/SQL implementation.

Object Type: {meta.get('ObjectType', 'N/A')}
Procedures: {meta.get('Procedures', 0)}
Functions: {meta.get('Functions', 0)}
Cursors: {meta.get('Cursors', 0)}
DML Operations: {meta.get('DML_Operations', 'N/A')}
Exception Handling: {meta.get('Exception_Handling', 'N/A')}
Transaction Control: {meta.get('Has_Transaction_Control', 'N/A')}

Provide detailed technical breakdown including logic flow and implementation details.
<|end|>
<|assistant|>
"""

# ========================================================
# LINEAGE MAPPING FUNCTIONS
# ========================================================

def calculate_deterministic_score(interface_row, sql_row):
    """Calculate deterministic matching score"""
    score = 0
    
    # Integration name matching
    if normalize_text(safe_get(interface_row, "integration")) in normalize_text(safe_get(sql_row, "queryname")):
        score += 30
    if normalize_text(safe_get(sql_row, "queryname")) in normalize_text(safe_get(interface_row, "integration")):
        score += 30
    
    # Application/file matching
    if normalize_text(safe_get(interface_row, "application")) in normalize_text(safe_get(sql_row, "file")):
        score += 15
    
    # Source system in tables
    source_sys = safe_get(interface_row, "source_system").lower()
    tables = safe_get(sql_row, "tables", "").lower()
    if source_sys and source_sys in tables:
        score += 15
    
    # Target system in file
    if normalize_text(safe_get(interface_row, "target_system")) in normalize_text(safe_get(sql_row, "file")):
        score += 10
    
    # Type validation (exclude non-SQL types)
    type_val = safe_get(interface_row, "type").lower()
    if type_val not in ["api", "application", "multiple", "pdf", "sharepoint job"]:
        score += 10
    
    return min(score, 100)

def calculate_semantic_score(interface_text, sql_text):
    """Calculate semantic similarity score"""
    interface_emb = embedding_model.encode(interface_text, convert_to_tensor=True)
    sql_emb = embedding_model.encode(sql_text, convert_to_tensor=True)
    similarity = util.cos_sim(interface_emb, sql_emb).item()
    
    if similarity >= 0.75:
        return 25
    elif similarity >= 0.65:
        return 15
    elif similarity >= 0.55:
        return 10
    return 0

def classify_confidence(score):
    """Classify confidence level based on score"""
    if score >= 85:
        return "High"
    elif score >= 65:
        return "Medium"
    elif score >= 45:
        return "Low"
    return "No Match"

def generate_lineage_mapping(interface_df, sql_df, enable_semantic=True, min_score=45):
    """Generate interface to SQL lineage mapping"""
    results = []
    
    # Progress bar
    progress_bar = st.progress(0)
    status_text = st.empty()
    
    total = len(interface_df)
    
    for idx, irow in enumerate(interface_df.iterrows()):
        i_idx, i_data = irow
        
        # Update progress
        progress = (idx + 1) / total
        progress_bar.progress(progress)
        status_text.text(f"Processing interface {idx + 1} of {total}...")
        
        # Skip non-SQL integration types
        if safe_get(i_data, "type").lower() in ["api", "application", "multiple", "pdf", "sharepoint job"]:
            continue
        
        for s_idx, s_data in sql_df.iterrows():
            # Calculate deterministic score
            det_score = calculate_deterministic_score(i_data, s_data)
            
            # Calculate semantic score if enabled
            sem_score = 0
            if enable_semantic:
                interface_text = f"{safe_get(i_data, 'integration')} {safe_get(i_data, 'description')}"
                sql_text = f"{safe_get(s_data, 'queryname')} {safe_get(s_data, 'selectcolumns')}"
                sem_score = calculate_semantic_score(interface_text, sql_text)
            
            # Combined score
            final_score = min(det_score + sem_score, 100)
            
            if final_score >= min_score:
                results.append({
                    "application": safe_get(i_data, "application"),
                    "integration": safe_get(i_data, "integration"),
                    "description": safe_get(i_data, "description"),
                    "source_system": safe_get(i_data, "source_system"),
                    "target_system": safe_get(i_data, "target_system"),
                    "type": safe_get(i_data, "type"),
                    "sql_file": safe_get(s_data, "file"),
                    "queryname": safe_get(s_data, "queryname"),
                    "deterministic_score": det_score,
                    "semantic_score": sem_score,
                    "final_score": final_score,
                    "confidence": classify_confidence(final_score)
                })
    
    progress_bar.empty()
    status_text.empty()
    
    return pd.DataFrame(results)

# ========================================================
# SQL ENRICHMENT FUNCTIONS
# ========================================================

def enrich_sql_metadata(sql_df):
    """Enrich SQL metadata with analysis and explanations"""
    enriched_rows = []
    
    progress_bar = st.progress(0)
    status_text = st.empty()
    
    total = len(sql_df)
    
    for idx, row in sql_df.iterrows():
        progress = (idx + 1) / total
        progress_bar.progress(progress)
        status_text.text(f"Analyzing SQL {idx + 1} of {total}...")
        
        raw_sql = safe_get(row, "rawsql")
        code_type = detect_code_type(raw_sql)
        
        enriched_row = row.to_dict()
        
        if code_type == "SQL":
            # Parse SQL
            meta = extract_sql_metadata(raw_sql)
            enriched_row.update(meta)
            
            # Governance rules
            rules = classify_governance_rules(meta.get("FilterConditions"))
            enriched_row["Governance_Rules"] = "; ".join(rules) if rules else "No specific rules identified"
            
            # Column glossary mapping
            glossary_mappings = []
            columns = meta.get("SelectColumns", "").split(",")
            for col in columns:
                col = col.strip()
                if col:
                    term, confidence = map_column_to_glossary(col)
                    if term:
                        glossary_mappings.append({
                            "column": col,
                            "business_term": term,
                            "definition": BUSINESS_GLOSSARY.get(term, ""),
                            "confidence": confidence
                        })
            enriched_row["Column_Glossary"] = json.dumps(glossary_mappings, indent=2)
            
            # Generate explanations if LLM available
            if llm_model:
                enriched_row["Business_Explanation"] = generate_llm_explanation(create_sql_business_prompt(meta))
                enriched_row["Technical_Explanation"] = generate_llm_explanation(create_sql_technical_prompt(meta))
            else:
                enriched_row["Business_Explanation"] = "LLM not available"
                enriched_row["Technical_Explanation"] = "LLM not available"
        
        elif code_type == "PLSQL":
            # Parse PL/SQL
            meta = parse_plsql(raw_sql)
            enriched_row.update(meta)
            
            enriched_row["Governance_Rules"] = "PL/SQL procedural code"
            enriched_row["Column_Glossary"] = "[]"
            
            # Generate explanations if LLM available
            if llm_model:
                enriched_row["Business_Explanation"] = generate_llm_explanation(create_plsql_business_prompt(meta))
                enriched_row["Technical_Explanation"] = generate_llm_explanation(create_plsql_technical_prompt(meta))
            else:
                enriched_row["Business_Explanation"] = "LLM not available"
                enriched_row["Technical_Explanation"] = "LLM not available"
        
        else:
            enriched_row["CodeType"] = "UNKNOWN"
            enriched_row["Governance_Rules"] = "Unable to parse"
            enriched_row["Column_Glossary"] = "[]"
            enriched_row["Business_Explanation"] = "Code type not recognized"
            enriched_row["Technical_Explanation"] = "Code type not recognized"
        
        enriched_rows.append(enriched_row)
    
    progress_bar.empty()
    status_text.empty()
    
    return pd.DataFrame(enriched_rows)

# ========================================================
# VISUALIZATION FUNCTIONS
# ========================================================

def create_system_lineage_graph(df, selected_sources=None, selected_targets=None, selected_types=None):
    """Create system-level lineage graph"""
    # Apply filters
    filtered_df = df.copy()
    if selected_sources:
        filtered_df = filtered_df[filtered_df["source_system"].isin(selected_sources)]
    if selected_targets:
        filtered_df = filtered_df[filtered_df["target_system"].isin(selected_targets)]
    if selected_types:
        filtered_df = filtered_df[filtered_df["type"].isin(selected_types)]
    
    # Group by system pairs
    nodes = {}
    edges = []
    grouped = defaultdict(list)
    
    for _, row in filtered_df.iterrows():
        src = safe_get(row, "source_system")
        tgt = safe_get(row, "target_system")
        grouped[(src, tgt)].append(row)
    
    # Create nodes
    for src, tgt in grouped.keys():
        nodes[src] = Node(id=src, label=src, size=32, shape="dot", color="#667eea")
        nodes[tgt] = Node(id=tgt, label=tgt, size=32, shape="dot", color="#764ba2")
    
    # Create edges
    for (src, tgt), rows in grouped.items():
        integration_list = [safe_get(r, "integration") for r in rows]
        type_list = [safe_get(r, "type") for r in rows]
        
        edges.append(
            Edge(
                id=f"{src}_{tgt}",
                source=src,
                target=tgt,
                label=f"{len(rows)} integrations",
                title="\\n".join(integration_list[:5]) + ("\\n..." if len(integration_list) > 5 else ""),
                color=edge_color_by_type(type_list),
                arrows="to",
                width=2
            )
        )
    
    return list(nodes.values()), edges, filtered_df

def create_integration_lineage_graph(df, source_system, target_system):
    """Create detailed integration lineage between two systems"""
    filtered = df[
        (df["source_system"] == source_system) & 
        (df["target_system"] == target_system)
    ]
    
    nodes = {
        source_system: Node(id=source_system, label=source_system, size=40, shape="dot", color="#667eea"),
        target_system: Node(id=target_system, label=target_system, size=40, shape="dot", color="#764ba2")
    }
    
    edges = []
    for idx, row in filtered.iterrows():
        integration = safe_get(row, "integration")
        int_type = safe_get(row, "type")
        
        edges.append(
            Edge(
                id=f"{integration}_{idx}",
                source=source_system,
                target=target_system,
                label=integration,
                title=f"Integration: {integration}\\nType: {int_type}",
                color=edge_color_by_type([int_type]),
                arrows="to",
                smooth={
                    "type": "curvedCW" if idx % 2 == 0 else "curvedCCW",
                    "roundness": 0.15 + (idx % 5) * 0.05
                }
            )
        )
    
    return list(nodes.values()), edges, filtered

# ========================================================
# MAIN APPLICATION
# ========================================================

def main():
    # Header
    st.markdown('<p class="main-header">🔍 Enterprise Data Explorer</p>', unsafe_allow_html=True)
    st.markdown('<p class="sub-header">End-to-end data lineage, SQL knowledge, and governance platform</p>', unsafe_allow_html=True)
    
    # Sidebar navigation
    st.sidebar.title("📍 Navigation")
    
    view = st.sidebar.radio(
        "Select View",
        [
            "🏠 Home & Upload",
            "🌐 System Lineage",
            "🔎 Integration Deep-Dive",
            "📊 SQL Knowledge Engine",
            "🔗 Interface-SQL Mapping",
            "⚖️ Governance Analytics"
        ]
    )
    
    st.sidebar.markdown("---")
    
    # ====================================================
    # VIEW 1: HOME & UPLOAD
    # ====================================================
    if view == "🏠 Home & Upload":
        st.header("📂 Data Upload & Management")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.subheader("📋 Interface Inventory")
            interface_file = st.file_uploader(
                "Upload Interface Inventory Excel",
                type=["xlsx"],
                key="interface_upload",
                help="Excel file with 'interface' sheet containing integration data"
            )
            
            if interface_file:
                with st.spinner("Loading interface data..."):
                    st.session_state.interface_df = load_interface_inventory(interface_file)
                
                if st.session_state.interface_df is not None:
                    st.success(f"✅ Loaded {len(st.session_state.interface_df)} interfaces")
                    with st.expander("Preview Data"):
                        st.dataframe(st.session_state.interface_df.head(10), use_container_width=True)
        
        with col2:
            st.subheader("💾 SQL Metadata")
            sql_file = st.file_uploader(
                "Upload SQL Metadata Excel",
                type=["xlsx"],
                key="sql_upload",
                help="Excel file with 'Queries' sheet containing SQL code"
            )
            
            if sql_file:
                with st.spinner("Loading SQL data..."):
                    st.session_state.sql_df = load_sql_metadata(sql_file)
                
                if st.session_state.sql_df is not None:
                    st.success(f"✅ Loaded {len(st.session_state.sql_df)} SQL queries")
                    with st.expander("Preview Data"):
                        st.dataframe(st.session_state.sql_df.head(10), use_container_width=True)
        
        st.markdown("---")
        
        # Dashboard metrics
        if st.session_state.interface_df is not None or st.session_state.sql_df is not None:
            st.subheader("📊 Data Summary")
            
            metric_cols = st.columns(4)
            
            if st.session_state.interface_df is not None:
                with metric_cols[0]:
                    st.markdown(
                        f'<div class="metric-card"><div class="metric-value">{len(st.session_state.interface_df)}</div>'
                        f'<div class="metric-label">Interfaces</div></div>',
                        unsafe_allow_html=True
                    )
                
                with metric_cols[1]:
                    unique_systems = len(pd.concat([
                        st.session_state.interface_df["source_system"],
                        st.session_state.interface_df["target_system"]
                    ]).unique())
                    st.markdown(
                        f'<div class="metric-card"><div class="metric-value">{unique_systems}</div>'
                        f'<div class="metric-label">Systems</div></div>',
                        unsafe_allow_html=True
                    )
            
            if st.session_state.sql_df is not None:
                with metric_cols[2]:
                    st.markdown(
                        f'<div class="metric-card"><div class="metric-value">{len(st.session_state.sql_df)}</div>'
                        f'<div class="metric-label">SQL Queries</div></div>',
                        unsafe_allow_html=True
                    )
                
                with metric_cols[3]:
                    if st.session_state.enriched_sql_df is not None:
                        enriched_count = len(st.session_state.enriched_sql_df)
                    else:
                        enriched_count = 0
                    st.markdown(
                        f'<div class="metric-card"><div class="metric-value">{enriched_count}</div>'
                        f'<div class="metric-label">Enriched</div></div>',
                        unsafe_allow_html=True
                    )
        
        # Processing actions
        if st.session_state.interface_df is not None and st.session_state.sql_df is not None:
            st.markdown("---")
            st.subheader("⚙️ Data Processing")
            
            proc_col1, proc_col2 = st.columns(2)
            
            with proc_col1:
                st.write("**Enrich SQL Metadata**")
                st.write("Add business context, governance rules, and glossary mappings")
                
                if st.button("🚀 Enrich SQL Data", type="primary", use_container_width=True):
                    with st.spinner("Enriching SQL metadata... This may take several minutes."):
                        st.session_state.enriched_sql_df = enrich_sql_metadata(st.session_state.sql_df)
                        
                        # Save to file
                        st.session_state.enriched_sql_df.to_excel(ENRICHED_SQL_FILE, index=False)
                        st.success(f"✅ Enriched {len(st.session_state.enriched_sql_df)} SQL queries")
            
            with proc_col2:
                st.write("**Generate Lineage Mapping**")
                st.write("Map interfaces to SQL queries using AI-powered matching")
                
                enable_semantic = st.checkbox("Enable Semantic Matching", value=True, key="home_semantic")
                min_score = st.slider("Minimum Confidence", 45, 100, 65, 5, key="home_min_score")
                
                if st.button("🔗 Generate Mapping", type="primary", use_container_width=True):
                    with st.spinner("Generating lineage mapping..."):
                        st.session_state.lineage_mapping_df = generate_lineage_mapping(
                            st.session_state.interface_df,
                            st.session_state.sql_df,
                            enable_semantic=enable_semantic,
                            min_score=min_score
                        )
                        
                        # Save to file
                        st.session_state.lineage_mapping_df.to_excel(LINEAGE_MAPPING_FILE, index=False)
                        st.success(f"✅ Generated {len(st.session_state.lineage_mapping_df)} mappings")
    
    # ====================================================
    # VIEW 2: SYSTEM LINEAGE
    # ====================================================
    elif view == "🌐 System Lineage":
        st.header("🌐 System-Level Data Lineage")
        
        if st.session_state.interface_df is None:
            st.warning("⚠️ Please upload Interface Inventory in the Home view")
            return
        
        df = st.session_state.interface_df
        
        # Filters
        st.sidebar.subheader("🎛️ Filters")
        
        source_filter = st.sidebar.multiselect(
            "Source Systems",
            sorted(df["source_system"].unique()),
            key="sys_source_filter"
        )
        
        target_filter = st.sidebar.multiselect(
            "Target Systems",
            sorted(df["target_system"].unique()),
            key="sys_target_filter"
        )
        
        type_filter = st.sidebar.multiselect(
            "Integration Types",
            sorted(df["type"].unique()),
            key="sys_type_filter"
        )
        
        # Create graph
        nodes, edges, filtered_df = create_system_lineage_graph(
            df,
            source_filter if source_filter else None,
            target_filter if target_filter else None,
            type_filter if type_filter else None
        )
        
        if not nodes:
            st.info("No data to display with current filters")
            return
        
        # Display graph
        config = Config(
            width="100%",
            height=700,
            directed=True,
            physics=False,
            hierarchical=True,
            nodeHierarchy={'direction': 'LR'},
            levelSeparation=250,
            nodeSpacing=150,
            interaction={"dragNodes": True, "zoomView": True, "navigationButtons": True},
            edges={"smooth": {"type": "cubicBezier", "roundness": 0.3}}
        )
        
        selected = agraph(nodes, edges, config)
        
        # Show inventory table
        st.markdown("---")
        st.subheader("📋 Integration Inventory")
        
        # If edge selected, filter to that connection
        display_df = filtered_df
        if selected and selected.get("edges"):
            edge_id = selected["edges"][0]
            if "_" in edge_id:
                src, tgt = edge_id.rsplit("_", 1)
                display_df = filtered_df[
                    (filtered_df["source_system"] == src) & 
                    (filtered_df["target_system"] == tgt)
                ]
        
        st.dataframe(
            display_df[["integration", "source_system", "target_system", "type", "description"]],
            use_container_width=True,
            height=400
        )
        
        # Download option
        csv = display_df.to_csv(index=False)
        st.download_button(
            "⬇️ Download Inventory",
            csv,
            "system_lineage.csv",
            "text/csv",
            use_container_width=False
        )
    
    # ====================================================
    # VIEW 3: INTEGRATION DEEP-DIVE
    # ====================================================
    elif view == "🔎 Integration Deep-Dive":
        st.header("🔎 Integration-Level Lineage")
        
        if st.session_state.interface_df is None:
            st.warning("⚠️ Please upload Interface Inventory in the Home view")
            return
        
        df = st.session_state.interface_df
        
        # System selection
        col1, col2 = st.columns(2)
        
        with col1:
            source = st.selectbox(
                "Source System",
                sorted(df["source_system"].unique()),
                key="dd_source"
            )
        
        with col2:
            targets = sorted(df[df["source_system"] == source]["target_system"].unique())
            target = st.selectbox(
                "Target System",
                targets,
                key="dd_target"
            )
        
        # Create graph
        nodes, edges, filtered_df = create_integration_lineage_graph(df, source, target)
        
        if not edges:
            st.info(f"No integrations found between {source} and {target}")
            return
        
        # Display graph
        config = Config(
            width="100%",
            height=600,
            directed=True,
            physics=True,
            hierarchical=False,
            interaction={"dragNodes": True, "zoomView": True, "navigationButtons": True}
        )
        
        selected = agraph(nodes, edges, config)
        
        # Show details
        st.markdown("---")
        
        display_df = filtered_df
        if selected and selected.get("edges"):
            edge_id = selected["edges"][0]
            # Extract integration name from edge ID
            integration_name = edge_id.rsplit("_", 1)[0]
            display_df = filtered_df[filtered_df["integration"] == integration_name]
        
        st.subheader("📋 Integration Details")
        st.dataframe(display_df, use_container_width=True, height=400)
    
    # ====================================================
    # VIEW 4: SQL KNOWLEDGE ENGINE
    # ====================================================
    elif view == "📊 SQL Knowledge Engine":
        st.header("📊 SQL Knowledge Engine")
        
        # Check for enriched data
        if st.session_state.enriched_sql_df is None:
            if os.path.exists(ENRICHED_SQL_FILE):
                st.session_state.enriched_sql_df = pd.read_excel(ENRICHED_SQL_FILE)
            elif st.session_state.sql_df is not None:
                st.info("SQL data not enriched yet. Run enrichment from Home view.")
                
                if st.button("🚀 Enrich Now"):
                    with st.spinner("Enriching SQL metadata..."):
                        st.session_state.enriched_sql_df = enrich_sql_metadata(st.session_state.sql_df)
                        st.session_state.enriched_sql_df.to_excel(ENRICHED_SQL_FILE, index=False)
                        st.success("✅ Enrichment complete!")
                        st.rerun()
            else:
                st.warning("⚠️ Please upload SQL Metadata in the Home view")
                return
        
        df = st.session_state.enriched_sql_df
        
        # Query selector
        st.subheader("🔍 Select SQL Query")
        
        search_term = st.text_input("🔎 Search queries", key="sql_search")
        
        if search_term:
            filtered_queries = df[
                df["queryname"].str.contains(search_term, case=False, na=False) |
                df.get("file", pd.Series()).str.contains(search_term, case=False, na=False)
            ]["queryname"].tolist()
        else:
            filtered_queries = df["queryname"].tolist()
        
        selected_query = st.selectbox(
            "Query Name",
            filtered_queries,
            key="sql_selector"
        )
        
        if not selected_query:
            st.info("No queries available")
            return
        
        # Get query details
        query_row = df[df["queryname"] == selected_query].iloc[0]
        
        # Display tabs
        st.markdown("---")
        
        # Metric row
        metric_cols = st.columns(4)
        with metric_cols[0]:
            st.metric("Code Type", query_row.get("CodeType", "Unknown"))
        with metric_cols[1]:
            if query_row.get("CodeType") == "SQL":
                st.metric("Columns", query_row.get("SelectColumnsCount", 0))
            else:
                st.metric("Object Type", query_row.get("ObjectType", "N/A"))
        with metric_cols[2]:
            st.metric("File", query_row.get("file", "Unknown"))
        with metric_cols[3]:
            gov_rules = query_row.get("Governance_Rules", "")
            rule_count = len(gov_rules.split(";")) if gov_rules else 0
            st.metric("Gov Rules", rule_count)
        
        st.markdown("---")
        
        # Tabs
        tab1, tab2, tab3, tab4, tab5 = st.tabs([
            "📘 Business View",
            "🛠️ Technical View",
            "💻 SQL Code",
            "📗 Column Glossary",
            "⚖️ Governance"
        ])
        
        with tab1:
            st.subheader("Business Explanation")
            st.write(query_row.get("Business_Explanation", "Not available"))
        
        with tab2:
            st.subheader("Technical Explanation")
            st.write(query_row.get("Technical_Explanation", "Not available"))
            
            if query_row.get("CodeType") == "SQL":
                st.markdown("**Query Metadata:**")
                col1, col2 = st.columns(2)
                with col1:
                    st.write("**Tables:**")
                    st.code(query_row.get("Tables", "N/A"), language="text")
                with col2:
                    st.write("**Joins:**")
                    st.code(query_row.get("JoinConditions", "N/A"), language="text")
                
                st.write("**Filters:**")
                st.code(query_row.get("FilterConditions", "N/A"), language="sql")
        
        with tab3:
            st.subheader("SQL Code")
            st.code(query_row.get("rawsql", "No SQL available"), language="sql")
        
        with tab4:
            st.subheader("Column to Business Glossary Mapping")
            glossary_json = query_row.get("Column_Glossary", "[]")
            try:
                glossary = json.loads(glossary_json) if isinstance(glossary_json, str) else []
                if glossary:
                    glossary_df = pd.DataFrame(glossary)
                    st.dataframe(glossary_df, use_container_width=True, height=400)
                else:
                    st.info("No glossary mappings available")
            except:
                st.error("Error parsing glossary data")
        
        with tab5:
            st.subheader("Governance Rules")
            rules = query_row.get("Governance_Rules", "No rules identified")
            if rules:
                for rule in rules.split(";"):
                    if rule.strip():
                        st.info(f"📌 {rule.strip()}")
            else:
                st.write("No specific governance rules identified")
    
    # ====================================================
    # VIEW 5: INTERFACE-SQL MAPPING
    # ====================================================
    elif view == "🔗 Interface-SQL Mapping":
        st.header("🔗 Interface to SQL Lineage Mapping")
        
        # Check for mapping data
        if st.session_state.lineage_mapping_df is None:
            if os.path.exists(LINEAGE_MAPPING_FILE):
                st.session_state.lineage_mapping_df = pd.read_excel(LINEAGE_MAPPING_FILE)
            elif st.session_state.interface_df is not None and st.session_state.sql_df is not None:
                st.info("Lineage mapping not generated yet. Configure and run from Home view.")
                
                col1, col2 = st.columns(2)
                with col1:
                    enable_semantic = st.checkbox("Enable Semantic Matching", value=True, key="map_semantic")
                with col2:
                    min_score = st.slider("Minimum Score", 45, 100, 65, 5, key="map_min_score")
                
                if st.button("🔗 Generate Mapping Now", type="primary"):
                    with st.spinner("Generating lineage mapping..."):
                        st.session_state.lineage_mapping_df = generate_lineage_mapping(
                            st.session_state.interface_df,
                            st.session_state.sql_df,
                            enable_semantic=enable_semantic,
                            min_score=min_score
                        )
                        st.session_state.lineage_mapping_df.to_excel(LINEAGE_MAPPING_FILE, index=False)
                        st.success("✅ Mapping complete!")
                        st.rerun()
            else:
                st.warning("⚠️ Please upload both Interface Inventory and SQL Metadata in Home view")
                return
        
        df = st.session_state.lineage_mapping_df
        
        if df.empty:
            st.info("No mappings found. Try lowering the minimum confidence score.")
            return
        
        # Filters
        st.sidebar.subheader("🎛️ Filters")
        
        conf_filter = st.sidebar.multiselect(
            "Confidence Level",
            ["High", "Medium", "Low"],
            default=["High", "Medium"],
            key="map_conf_filter"
        )
        
        min_score_filter = st.sidebar.slider(
            "Minimum Score",
            45, 100, 65, 5,
            key="map_score_filter"
        )
        
        # Apply filters
        filtered_df = df[
            (df["confidence"].isin(conf_filter)) &
            (df["final_score"] >= min_score_filter)
        ].sort_values("final_score", ascending=False)
        
        # Display metrics
        metric_cols = st.columns(4)
        with metric_cols[0]:
            st.metric("Total Mappings", len(filtered_df))
        with metric_cols[1]:
            high_conf = len(filtered_df[filtered_df["confidence"] == "High"])
            st.metric("High Confidence", high_conf)
        with metric_cols[2]:
            med_conf = len(filtered_df[filtered_df["confidence"] == "Medium"])
            st.metric("Medium Confidence", med_conf)
        with metric_cols[3]:
            avg_score = filtered_df["final_score"].mean() if not filtered_df.empty else 0
            st.metric("Avg Score", f"{avg_score:.1f}")
        
        st.markdown("---")
        
        # Interactive table
        st.subheader("📊 Lineage Mapping Results")
        
        gb = GridOptionsBuilder.from_dataframe(filtered_df)
        gb.configure_selection(selection_mode="single", use_checkbox=True)
        gb.configure_column("final_score", header_name="Score", width=80)
        gb.configure_column("confidence", header_name="Confidence", width=100)
        grid_options = gb.build()
        
        grid_response = AgGrid(
            filtered_df,
            gridOptions=grid_options,
            update_mode=GridUpdateMode.SELECTION_CHANGED,
            theme="streamlit",
            height=400,
            allow_unsafe_jscode=True
        )
        
        selected_rows = grid_response.get("selected_rows", [])
        
        # Show details for selected row
        if selected_rows is not None and len(selected_rows) > 0:
            st.markdown("---")
            st.subheader("🔍 Mapping Details")
            
            selected = selected_rows[0] if isinstance(selected_rows, list) else selected_rows.iloc[0]
            
            detail_col1, detail_col2 = st.columns(2)
            
            with detail_col1:
                st.write("**Interface Information:**")
                st.write(f"**Integration:** {selected.get('integration', 'N/A')}")
                st.write(f"**Application:** {selected.get('application', 'N/A')}")
                st.write(f"**Source:** {selected.get('source_system', 'N/A')}")
                st.write(f"**Target:** {selected.get('target_system', 'N/A')}")
                st.write(f"**Type:** {selected.get('type', 'N/A')}")
                st.write(f"**Description:** {selected.get('description', 'N/A')}")
            
            with detail_col2:
                st.write("**SQL Information:**")
                st.write(f"**Query Name:** {selected.get('queryname', 'N/A')}")
                st.write(f"**File:** {selected.get('sql_file', 'N/A')}")
                st.write(f"**Deterministic Score:** {selected.get('deterministic_score', 0)}")
                st.write(f"**Semantic Score:** {selected.get('semantic_score', 0)}")
                st.write(f"**Final Score:** {selected.get('final_score', 0)}")
                st.write(f"**Confidence:** {selected.get('confidence', 'N/A')}")
            
            # Show SQL if available
            if st.session_state.sql_df is not None:
                query_name = selected.get('queryname', '')
                sql_row = st.session_state.sql_df[st.session_state.sql_df["queryname"] == query_name]
                
                if not sql_row.empty:
                    st.markdown("---")
                    st.subheader("💻 Associated SQL Code")
                    
                    with st.expander("View SQL", expanded=False):
                        st.code(sql_row.iloc[0].get("rawsql", "SQL not available"), language="sql")
        
        # Download button
        st.markdown("---")
        csv = filtered_df.to_csv(index=False)
        st.download_button(
            "⬇️ Download Lineage Mapping",
            csv,
            "interface_sql_lineage.csv",
            "text/csv"
        )
    
    # ====================================================
    # VIEW 6: GOVERNANCE ANALYTICS
    # ====================================================
    elif view == "⚖️ Governance Analytics":
        st.header("⚖️ Data Governance Analytics")
        
        if st.session_state.enriched_sql_df is None:
            if os.path.exists(ENRICHED_SQL_FILE):
                st.session_state.enriched_sql_df = pd.read_excel(ENRICHED_SQL_FILE)
            else:
                st.warning("⚠️ Please enrich SQL metadata first from Home view")
                return
        
        df = st.session_state.enriched_sql_df
        
        # Summary metrics
        st.subheader("📊 Governance Overview")
        
        metric_cols = st.columns(4)
        
        with metric_cols[0]:
            sql_count = len(df[df["CodeType"] == "SQL"])
            st.metric("SQL Queries", sql_count)
        
        with metric_cols[1]:
            plsql_count = len(df[df["CodeType"] == "PLSQL"])
            st.metric("PL/SQL Objects", plsql_count)
        
        with metric_cols[2]:
            # Count queries with governance rules
            with_rules = len(df[df["Governance_Rules"].str.len() > 0])
            st.metric("With Gov Rules", with_rules)
        
        with metric_cols[3]:
            # Count queries with glossary mappings
            with_glossary = len(df[df["Column_Glossary"].str.len() > 2])  # More than just "[]"
            st.metric("With Glossary", with_glossary)
        
        st.markdown("---")
        
        # Tabs for different analytics
        tab1, tab2, tab3 = st.tabs([
            "📈 Governance Rules",
            "📗 Glossary Coverage",
            "🔍 Code Analysis"
        ])
        
        with tab1:
            st.subheader("Governance Rules Distribution")
            
            # Extract all rules
            all_rules = []
            for rules_str in df["Governance_Rules"].dropna():
                if isinstance(rules_str, str) and rules_str:
                    all_rules.extend([r.strip() for r in rules_str.split(";") if r.strip()])
            
            if all_rules:
                rule_counts = pd.Series(all_rules).value_counts()
                
                # Chart
                st.bar_chart(rule_counts)
                
                # Table
                st.dataframe(
                    rule_counts.reset_index().rename(columns={"index": "Rule", 0: "Count"}),
                    use_container_width=True
                )
            else:
                st.info("No governance rules identified")
        
        with tab2:
            st.subheader("Business Glossary Coverage")
            
            # Extract all glossary mappings
            all_mappings = []
            for glossary_str in df["Column_Glossary"].dropna():
                try:
                    glossary = json.loads(glossary_str) if isinstance(glossary_str, str) else []
                    all_mappings.extend(glossary)
                except:
                    pass
            
            if all_mappings:
                mapping_df = pd.DataFrame(all_mappings)
                
                # Coverage by business term
                term_counts = mapping_df["business_term"].value_counts()
                
                st.write("**Most Common Business Terms:**")
                st.bar_chart(term_counts.head(15))
                
                # Confidence distribution
                st.write("**Mapping Confidence Distribution:**")
                confidence_bins = pd.cut(mapping_df["confidence"], bins=[0, 0.6, 0.8, 1.0], labels=["Low", "Medium", "High"])
                st.bar_chart(confidence_bins.value_counts())
                
                # Detailed table
                with st.expander("View All Mappings"):
                    st.dataframe(mapping_df, use_container_width=True, height=400)
            else:
                st.info("No glossary mappings available")
        
        with tab3:
            st.subheader("Code Analysis Summary")
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.write("**SQL Queries:**")
                sql_df = df[df["CodeType"] == "SQL"]
                
                if not sql_df.empty:
                    # Average columns per query
                    avg_cols = sql_df["SelectColumnsCount"].mean() if "SelectColumnsCount" in sql_df.columns else 0
                    st.metric("Avg Columns/Query", f"{avg_cols:.1f}")
                    
                    # Queries with joins
                    with_joins = len(sql_df[sql_df["JoinConditions"].str.len() > 0]) if "JoinConditions" in sql_df.columns else 0
                    st.metric("With Joins", with_joins)
                    
                    # Queries with filters
                    with_filters = len(sql_df[sql_df["FilterConditions"].str.len() > 0]) if "FilterConditions" in sql_df.columns else 0
                    st.metric("With Filters", with_filters)
                else:
                    st.info("No SQL queries")
            
            with col2:
                st.write("**PL/SQL Objects:**")
                plsql_df = df[df["CodeType"] == "PLSQL"]
                
                if not plsql_df.empty:
                    # Object types
                    if "ObjectType" in plsql_df.columns:
                        obj_types = plsql_df["ObjectType"].value_counts()
                        st.write("**Object Types:**")
                        for obj_type, count in obj_types.items():
                            st.write(f"- {obj_type}: {count}")
                    
                    # With exception handling
                    with_exceptions = len(plsql_df[plsql_df.get("Exception_Handling", "") == "Yes"])
                    st.metric("With Exception Handling", with_exceptions)
                    
                    # With transaction control
                    with_trans = len(plsql_df[plsql_df.get("Has_Transaction_Control", "") == "Yes"])
                    st.metric("With Trans Control", with_trans)
                else:
                    st.info("No PL/SQL objects")
        
        # Export options
        st.markdown("---")
        st.subheader("📥 Export Data")
        
        export_col1, export_col2 = st.columns(2)
        
        with export_col1:
            # Export enriched SQL
            csv_enriched = df.to_csv(index=False)
            st.download_button(
                "⬇️ Download Enriched SQL Data",
                csv_enriched,
                "enriched_sql_metadata.csv",
                "text/csv",
                use_container_width=True
            )
        
        with export_col2:
            # Export governance summary
            if st.button("📊 Generate Governance Report", use_container_width=True):
                st.info("Governance report generation coming soon!")

if __name__ == "__main__":
    main()
