#!/bin/bash

# ========================================================
# Enterprise Data Explorer - Setup Script
# ========================================================

echo "=========================================================="
echo "  Enterprise Data Explorer - Automated Setup"
echo "=========================================================="
echo ""

# Check Python version
echo "Checking Python version..."
python_version=$(python --version 2>&1 | awk '{print $2}')
echo "Found Python $python_version"

if ! python -c "import sys; exit(0 if sys.version_info >= (3,9) else 1)"; then
    echo "❌ Error: Python 3.9 or higher is required"
    exit 1
fi

echo "✅ Python version OK"
echo ""

# Create virtual environment
echo "Creating virtual environment..."
if [ ! -d "venv" ]; then
    python -m venv venv
    echo "✅ Virtual environment created"
else
    echo "ℹ️  Virtual environment already exists"
fi
echo ""

# Activate virtual environment
echo "Activating virtual environment..."
if [[ "$OSTYPE" == "msys" || "$OSTYPE" == "win32" ]]; then
    source venv/Scripts/activate
else
    source venv/bin/activate
fi
echo "✅ Virtual environment activated"
echo ""

# Upgrade pip
echo "Upgrading pip..."
pip install --upgrade pip --quiet
echo "✅ Pip upgraded"
echo ""

# Install dependencies
echo "Installing dependencies..."
echo "This may take several minutes..."
pip install -r requirements.txt --quiet
if [ $? -eq 0 ]; then
    echo "✅ All dependencies installed"
else
    echo "❌ Error installing dependencies"
    exit 1
fi
echo ""

# Generate sample data
echo "Generating sample data for testing..."
python generate_sample_data.py --interfaces 30 --queries 20
echo ""

# Check if models are available locally
echo "Checking for AI models..."
if [ -d "C:/SEI/AneeshModel" ]; then
    echo "✅ Local models found"
else
    echo "ℹ️  Local models not found - will download from HuggingFace on first run"
    echo "   This may take 10-15 minutes on first startup"
fi
echo ""

echo "=========================================================="
echo "  Setup Complete! 🎉"
echo "=========================================================="
echo ""
echo "Next steps:"
echo "1. Activate the virtual environment (if not already):"
if [[ "$OSTYPE" == "msys" || "$OSTYPE" == "win32" ]]; then
    echo "   venv\\Scripts\\activate"
else
    echo "   source venv/bin/activate"
fi
echo ""
echo "2. Run the application:"
echo "   streamlit run enterprise_data_explorer.py"
echo ""
echo "3. Upload sample data files:"
echo "   - sample_interface_inventory.xlsx"
echo "   - sample_sql_metadata.xlsx"
echo ""
echo "4. Explore the features!"
echo ""
echo "For more information, see:"
echo "- QUICKSTART.md for a 5-minute guide"
echo "- README.md for complete documentation"
echo ""
echo "=========================================================="
