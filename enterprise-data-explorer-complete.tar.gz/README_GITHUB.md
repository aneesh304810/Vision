# 🔍 Enterprise Data Explorer

[![Python Version](https://img.shields.io/badge/python-3.9%2B-blue)](https://www.python.org/downloads/)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](LICENSE)
[![Streamlit](https://img.shields.io/badge/streamlit-1.28%2B-FF4B4B.svg)](https://streamlit.io)
[![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)

> **End-to-end data lineage visualization, SQL knowledge management, and governance analytics platform**

Enterprise Data Explorer is a unified Streamlit application that helps you understand, document, and govern your data ecosystem through interactive visualizations and AI-powered analysis.

![Enterprise Data Explorer Demo](https://via.placeholder.com/800x400.png?text=Demo+Screenshot)

---

## ✨ Features

### 🌐 **System Lineage Visualization**
- Interactive network graphs showing data flows between systems
- Filter by source, target, or integration type
- Click edges to drill down into integration details

### 🔎 **Integration Deep-Dive**
- Detailed view of connections between any two systems
- Multi-edge visualization with curved routing
- Complete integration inventory

### 📊 **SQL Knowledge Engine**
- AI-powered business and technical explanations
- Automatic SQL/PL-SQL parsing and metadata extraction
- Column-to-business glossary mapping
- Governance rule identification

### 🔗 **Interface-SQL Mapping**
- Intelligent matching of interfaces to SQL queries
- Deterministic + semantic similarity scoring
- Confidence classification (High/Medium/Low)
- Interactive drill-down capabilities

### ⚖️ **Governance Analytics**
- Dashboard of governance rule coverage
- Business glossary usage statistics
- Code complexity analysis
- Export and reporting capabilities

---

## 🚀 Quick Start

### Prerequisites
- Python 3.9 or higher
- 8GB+ RAM recommended
- Multi-core CPU (8+ cores for best performance)

### Installation

**Option 1: Automated Setup (Recommended)**

```bash
# Download and extract
tar -xzf enterprise-data-explorer.tar.gz
cd enterprise-data-explorer

# Run setup script
./setup.sh        # Linux/Mac
setup.bat         # Windows

# Launch application
streamlit run enterprise_data_explorer.py
```

**Option 2: Manual Setup**

```bash
# Clone repository
git clone https://github.com/yourusername/enterprise-data-explorer.git
cd enterprise-data-explorer

# Create virtual environment
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Generate sample data
python generate_sample_data.py

# Run application
streamlit run enterprise_data_explorer.py
```

### First Steps

1. Open browser to `http://localhost:8501`
2. Upload sample data files (or your own)
3. Click "Enrich SQL Data" to analyze
4. Click "Generate Mapping" to create lineage
5. Explore through different views!

📖 See [QUICKSTART.md](QUICKSTART.md) for detailed walkthrough

---

## 📊 Demo with Sample Data

```bash
# Generate 50 interfaces and 30 SQL queries
python generate_sample_data.py --interfaces 50 --queries 30

# Files created:
# - sample_interface_inventory.xlsx
# - sample_sql_metadata.xlsx

# Upload these in the application to explore features
```

---

## 📂 Project Structure

```
enterprise-data-explorer/
├── enterprise_data_explorer.py    # Main application
├── config.py                       # Configuration settings
├── generate_sample_data.py         # Test data generator
├── requirements.txt                # Python dependencies
├── setup.sh / setup.bat           # Installation scripts
├── README.md                       # This file
├── QUICKSTART.md                  # 5-minute setup guide
├── ARCHITECTURE.md                # Technical documentation
├── CONTRIBUTING.md                # Contribution guidelines
├── CHANGELOG.md                   # Version history
├── LICENSE                        # MIT License
└── .gitignore                     # Git ignore rules
```

---

## 🎯 Use Cases

### For Data Engineers
- **Map data lineage** across systems
- **Document SQL queries** automatically
- **Identify governance gaps**
- **Track data flows**

### For Data Architects
- **Visualize system dependencies**
- **Assess integration complexity**
- **Plan migrations and consolidations**
- **Document data architecture**

### For Compliance Teams
- **Audit data governance rules**
- **Track sensitive data usage**
- **Generate compliance reports**
- **Maintain data dictionaries**

### For Business Analysts
- **Understand data sources**
- **Find relevant queries**
- **Read business explanations**
- **Access data definitions**

---

## 🔧 Configuration

All settings can be customized in `config.py`:

```python
# AI Models
EMBEDDING_MODEL_PATH = "all-MiniLM-L6-v2"
LLM_MODEL_PATH = "microsoft/Phi-3-mini-4k-instruct"
USE_LLM = True

# Performance
CPU_THREADS = 12
DEFAULT_MIN_CONFIDENCE_SCORE = 65

# Business Glossary
BUSINESS_GLOSSARY = {
    "ACCOUNT_NUMBER": "Unique account identifier",
    # Add your terms here
}
```

See [Configuration Documentation](README.md#configuration) for all options.

---

## 📸 Screenshots

### System Lineage View
![System Lineage](https://via.placeholder.com/600x400.png?text=System+Lineage)

### SQL Knowledge Engine
![SQL Knowledge](https://via.placeholder.com/600x400.png?text=SQL+Knowledge+Engine)

### Governance Analytics
![Governance](https://via.placeholder.com/600x400.png?text=Governance+Analytics)

---

## 🛠️ Technology Stack

| Component | Technology |
|-----------|-----------|
| **Framework** | Streamlit |
| **Language** | Python 3.9+ |
| **AI/ML** | PyTorch, Transformers, Sentence-Transformers |
| **SQL Parsing** | SQLGlot |
| **Visualization** | Streamlit-AgGraph, Streamlit-AgGrid |
| **Data Processing** | Pandas, NumPy |

---

## 📈 Performance

| Dataset Size | Processing Time | Memory Usage |
|--------------|-----------------|--------------|
| 100 interfaces + 50 SQL | ~2 min | ~2 GB |
| 500 interfaces + 200 SQL | ~10 min | ~4 GB |
| 1000 interfaces + 500 SQL | ~25 min | ~8 GB |

*With LLM enabled on 12-core CPU*

---

## 🤝 Contributing

We welcome contributions! Please see [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

### Areas We Need Help
- [ ] Unit tests and test coverage
- [ ] Additional SQL dialect support
- [ ] Performance optimizations
- [ ] Documentation improvements
- [ ] Bug fixes

### Quick Contribution Guide
1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

---

## 📝 Documentation

- **[README.md](README.md)** - Complete user guide and reference
- **[QUICKSTART.md](QUICKSTART.md)** - Get started in 5 minutes
- **[ARCHITECTURE.md](ARCHITECTURE.md)** - Technical architecture and design
- **[CONTRIBUTING.md](CONTRIBUTING.md)** - How to contribute
- **[CHANGELOG.md](CHANGELOG.md)** - Version history

---

## 🐛 Known Issues

- LLM inference can be slow on CPU-only machines
- Large datasets (5000+ queries) may require significant memory
- Initial model download requires internet connection

See [Issues](../../issues) for full list and workarounds.

---

## 🗺️ Roadmap

### Version 1.1 (Q2 2025)
- [ ] User authentication
- [ ] Database backend option
- [ ] Query optimization hints
- [ ] Excel export for all views

### Version 1.2 (Q3 2025)
- [ ] API endpoints
- [ ] Real-time data refresh
- [ ] Advanced filtering
- [ ] Data quality scoring

### Version 2.0 (Q4 2025)
- [ ] Natural language queries
- [ ] Collaborative annotations
- [ ] Impact analysis
- [ ] Auto-documentation generation

---

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

---

## 🙏 Acknowledgments

- **Streamlit** for the amazing web framework
- **HuggingFace** for Transformers and model hosting
- **SQLGlot** for SQL parsing capabilities
- **All contributors** who help improve this project

---

## 📞 Support

- 📖 [Documentation](README.md)
- 🐛 [Report Bug](../../issues/new?labels=bug)
- 💡 [Request Feature](../../issues/new?labels=enhancement)
- 💬 [Discussions](../../discussions)

---

## ⭐ Star History

If this project helps you, please consider giving it a star! ⭐

[![Star History Chart](https://api.star-history.com/svg?repos=yourusername/enterprise-data-explorer&type=Date)](https://star-history.com/#yourusername/enterprise-data-explorer&Date)

---

<div align="center">

**Built with ❤️ for the data community**

[Report Bug](../../issues) · [Request Feature](../../issues) · [Documentation](README.md)

</div>
