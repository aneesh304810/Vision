# 🔍 Enterprise Data Explorer

**End-to-end Data Lineage, SQL Knowledge, and Governance Platform**

A unified Streamlit application that combines data lineage visualization, SQL/PL-SQL analysis, interface-to-SQL mapping, and governance analytics into one comprehensive platform.

---

## 🎯 Features

### 1. **System Lineage Visualization** 🌐
- Interactive graph showing data flows between systems
- Filter by source, target, and integration type
- Click edges to see integration details
- Export lineage mappings

### 2. **Integration Deep-Dive** 🔎
- Drill down into specific system-to-system connections
- View all integrations between any two systems
- Curved multi-edge visualization for clarity

### 3. **SQL Knowledge Engine** 📊
- AI-powered business and technical explanations
- Automatic SQL parsing and metadata extraction
- Column-to-business glossary mapping
- Governance rule identification

### 4. **Interface-SQL Mapping** 🔗
- Intelligent matching of interfaces to SQL queries
- Deterministic + semantic similarity scoring
- Confidence classification (High/Medium/Low)
- Interactive drill-down into mappings

### 5. **Governance Analytics** ⚖️
- Dashboard of governance rule coverage
- Business glossary usage statistics
- Code complexity analysis
- Export capabilities

---

## 📋 Prerequisites

### System Requirements
- Python 3.9 or higher
- 12+ GB RAM recommended (for LLM models)
- Multi-core CPU (8+ cores recommended)

### AI Models (Optional but Recommended)
The application works with local or online models:

1. **Embedding Model** (Required for semantic matching):
   - Default: `all-MiniLM-L6-v2` (auto-downloads from HuggingFace)
   - Local path: `C:/SEI/AneeshModel/all-minilm-l6-v2`

2. **LLM Model** (Optional for AI explanations):
   - Phi-3 Mini Instruct (3B parameters)
   - Local path: `C:/SEI/AneeshModel/phi-3-pytorch-phi-3.5-mini-instruct-v2`
   - Can be downloaded from HuggingFace: `microsoft/Phi-3-mini-4k-instruct`

> **Note**: The app will work without the LLM model, but SQL explanations will be marked as "LLM not available"

---

## 🚀 Installation

### Step 1: Clone or Download
```bash
# If you have the files locally
cd /path/to/enterprise_data_explorer
```

### Step 2: Create Virtual Environment (Recommended)
```bash
python -m venv venv

# Windows
venv\Scripts\activate

# Linux/Mac
source venv/bin/activate
```

### Step 3: Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 4: Run the Application
```bash
streamlit run enterprise_data_explorer.py
```

The application will open in your default browser at `http://localhost:8501`

---

## 📊 Input Data Requirements

### 1. Interface Inventory Excel

**Required Sheet**: `interface`

**Required Columns**:
- `source_system` - Source system name
- `target_system` - Target system name
- `integration` - Integration/interface name
- `type` - Integration type (API, Batch, Feed, etc.)

**Optional Columns**:
- `application` - Application name
- `description` - Integration description
- `inbound_outbound` - Direction indicator

**Example**:
```
| source_system | target_system | integration      | type  | description                    |
|---------------|---------------|------------------|-------|--------------------------------|
| SAP           | Salesforce    | Customer_Sync    | API   | Real-time customer data sync   |
| Oracle        | DataWarehouse | Daily_Extract    | Batch | Nightly data warehouse load    |
```

### 2. SQL Metadata Excel

**Required Sheet**: `Queries`

**Required Columns**:
- `queryname` - Unique query identifier
- `rawsql` - Full SQL or PL/SQL code

**Optional Columns**:
- `file` - Source file name
- `tables` - Comma-separated table list
- `selectcolumns` - Comma-separated column list

**Example**:
```
| queryname       | file              | rawsql                                    |
|-----------------|-------------------|-------------------------------------------|
| customer_query  | etl_customer.sql  | SELECT * FROM customers WHERE status='A'  |
| proc_update_acct| update_proc.pls   | CREATE PROCEDURE update_account AS...     |
```

---

## 🎮 User Guide

### Getting Started

1. **Upload Data** (Home & Upload view)
   - Upload Interface Inventory Excel
   - Upload SQL Metadata Excel
   - Review data summary dashboard

2. **Process Data**
   - Click "Enrich SQL Data" to add AI-powered analysis
   - Click "Generate Mapping" to create interface-SQL lineage
   - Wait for processing to complete (may take several minutes)

3. **Explore**
   - Navigate through different views using the sidebar
   - Apply filters to focus on specific systems or integration types
   - Click on graphs and tables for interactive drill-down

### View Descriptions

#### 🏠 Home & Upload
- Central hub for data management
- Upload and validate input files
- Trigger data processing operations
- View summary metrics

#### 🌐 System Lineage
- High-level view of all system connections
- Interactive network graph
- Filter by source, target, or type
- Click edges to see integration details

#### 🔎 Integration Deep-Dive
- Focus on specific system-to-system connections
- See all integrations between two systems
- Multiple edge visualization

#### 📊 SQL Knowledge Engine
- Browse and analyze SQL queries
- View AI-generated business explanations
- See technical implementation details
- Explore column glossary mappings
- Review governance rules

#### 🔗 Interface-SQL Mapping
- See which interfaces use which SQL queries
- Confidence scoring with filters
- Interactive table with drill-down
- View matched SQL code

#### ⚖️ Governance Analytics
- Governance rule distribution
- Business glossary coverage metrics
- Code complexity analysis
- Export governance reports

---

## 🔧 Configuration

### Model Paths

Edit the following in `enterprise_data_explorer.py` to match your local setup:

```python
# Around line 90-110
@st.cache_resource
def load_embedding_model():
    try:
        return SentenceTransformer("C:/SEI/AneeshModel/all-minilm-l6-v2")
    except:
        return SentenceTransformer("all-MiniLM-L6-v2")  # Online fallback

@st.cache_resource
def load_llm_model():
    try:
        model_path = "C:/SEI/AneeshModel/phi-3-pytorch-phi-3.5-mini-instruct-v2"
        # ... rest of function
```

### Business Glossary

Customize the business glossary around line 400:

```python
BUSINESS_GLOSSARY = {
    "ACCOUNT_NUMBER": "Unique account identifier for customer accounts",
    "CUSTOMER_ID": "Unique customer identifier",
    # Add your own mappings here
}
```

### CPU Thread Count

Adjust for your system around line 35:

```python
torch.set_num_threads(12)  # Change to match your CPU cores
```

---

## 📁 Output Files

The application generates the following files:

1. **enriched_sql_metadata.xlsx**
   - Enriched SQL metadata with analysis
   - Business and technical explanations
   - Governance rules
   - Column glossary mappings

2. **interface_sql_lineage.xlsx**
   - Interface-to-SQL mapping results
   - Confidence scores
   - Matching details

These files are cached and reloaded on subsequent runs.

---

## 🎨 Customization

### Adding New Governance Rules

Edit the `classify_governance_rules()` function around line 370:

```python
def classify_governance_rules(filter_sql):
    if not filter_sql:
        return []
    
    f = str(filter_sql).upper()
    rules = []
    
    # Add your custom rules here
    if "YOUR_PATTERN" in f:
        rules.append("Your custom rule description")
    
    return rules
```

### Customizing Colors

Edit edge colors around line 160:

```python
color_map = {
    "api": "#42A5F5",      # Blue
    "batch": "#FB8C00",    # Orange
    # Add your own type: color mappings
}
```

### Adding New Metrics

You can add custom metrics in any view. Example in the Home view:

```python
with metric_cols[4]:
    custom_metric = len(df)  # Your calculation
    st.metric("Custom Metric", custom_metric)
```

---

## 🐛 Troubleshooting

### Common Issues

**1. Model Loading Fails**
```
Solution: The app will fall back to online models. Check internet connection or verify local model paths.
```

**2. Excel Sheet Not Found**
```
Error: "Sheet 'interface' not found"
Solution: Ensure your Excel file has the correct sheet name. Check spelling and case sensitivity.
```

**3. Memory Issues**
```
Error: Out of memory
Solution: 
- Close other applications
- Reduce torch.set_num_threads()
- Process smaller batches of data
- Use a machine with more RAM
```

**4. Missing Columns**
```
Error: "Missing required columns"
Solution: Check your Excel file has all required columns. Use the exact names specified.
```

**5. Slow Performance**
```
Solution:
- Disable semantic matching temporarily
- Process data in smaller batches
- Use a machine with more CPU cores
- Check if LLM model is local (faster) vs online
```

### Debug Mode

To see detailed errors, run with:
```bash
streamlit run enterprise_data_explorer.py --logger.level=debug
```

---

## 📈 Performance Tips

1. **First-time Setup**:
   - Initial model downloads may take 10-15 minutes
   - Subsequent runs are faster due to caching

2. **Large Datasets**:
   - For 1000+ queries, enrichment may take 30+ minutes
   - Consider processing in batches
   - Use deterministic-only matching (disable semantic) for speed

3. **Caching**:
   - Models are cached in memory
   - Processed data is saved to Excel files
   - Use "Clear Cache" in Streamlit menu to refresh

---

## 🔒 Security Considerations

- **Data Privacy**: All processing is local. No data is sent to external services (unless using online models)
- **SQL Injection**: Input data is not executed, only parsed
- **Access Control**: Consider adding authentication if deploying in production

---

## 🚀 Deployment Options

### Local Development
```bash
streamlit run enterprise_data_explorer.py
```

### Streamlit Cloud
1. Push to GitHub
2. Connect to Streamlit Cloud
3. Configure secrets for any API keys
4. Deploy

### Docker (Example)
```dockerfile
FROM python:3.9-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY enterprise_data_explorer.py .
EXPOSE 8501
CMD ["streamlit", "run", "enterprise_data_explorer.py"]
```

### On-Premise Server
```bash
# Run with custom port and allow external access
streamlit run enterprise_data_explorer.py --server.port 8501 --server.address 0.0.0.0
```

---

## 🤝 Contributing

Areas for enhancement:
- [ ] Add support for more SQL dialects
- [ ] Implement user authentication
- [ ] Add Excel export for governance reports
- [ ] Support for real-time data refresh
- [ ] Additional visualization types
- [ ] Query optimization recommendations
- [ ] Data quality metrics

---

## 📝 Version History

### v1.0.0 (Current)
- Initial unified platform release
- Combined 4 separate applications
- Added comprehensive governance analytics
- Implemented end-to-end workflow
- Full documentation

---

## 📧 Support

For issues or questions:
1. Check the Troubleshooting section
2. Review input data format requirements
3. Verify model paths and dependencies
4. Check Streamlit logs for detailed errors

---

## 📜 License

This application is provided as-is for internal enterprise use.

---

## 🙏 Acknowledgments

Built with:
- **Streamlit** - Web framework
- **Sentence Transformers** - Semantic matching
- **SQLGlot** - SQL parsing
- **Phi-3 Mini** - AI explanations
- **Streamlit-AgGraph** - Network visualization

---

**Happy Exploring! 🚀**
